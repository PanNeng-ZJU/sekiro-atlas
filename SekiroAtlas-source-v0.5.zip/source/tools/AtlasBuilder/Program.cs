using System.Numerics;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using SoulsFormats;

Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
try
{
    if (args.Length == 0) throw new ArgumentException("Commands: extract GAME OUT RESOURCES [prefix ...] | inspect UNPACKED OUT | bake UNPACKED MAP OUTPUT [SIZE]");
    switch (args[0])
    {
        case "extract": Extract(args[1], args[2], args[3], args.Skip(4).ToArray()); break;
        case "inspect": Inspect(args[1], args[2]); break;
        case "bake": Baker.Run(args[1], args[2], args[3], args.Length > 4 ? int.Parse(args[4]) : 2048); break;
        case "self-test": Baker.SelfTest(); break;
        case "refresh": Baker.Refresh(args[1],args[2]); break;
        case "model-info":
            var binder=BND4.Read(args[1]);
            foreach(var entry in binder.Files.Take(3))
            {
                Console.WriteLine(entry.Name);
                if(!FLVER2.Is(entry.Bytes)) continue;
                var model=FLVER2.Read(entry.Bytes);
                Console.WriteLine($"Meshes={model.Meshes.Count}, vertices={model.Meshes.Sum(m=>m.Vertices.Count)}");
                foreach(var m in model.Materials.Take(25)) Console.WriteLine(JsonSerializer.Serialize(new {m.Name,m.MTD,m.Textures}));
            }
            break;
        case "events-info":
            foreach(var file in Directory.GetFiles(Path.Combine(args[1],"event"),"m11_0?_00_00.emevd*"))
            {
                var script=EMEVD.Read(file);
                foreach(var ev in script.Events) foreach(var ins in ev.Instructions)
                    if(ins.Bank==2009)
                        Console.WriteLine($"{Path.GetFileName(file)} event={ev.ID} ({ins.Bank},{ins.ID}) {Convert.ToHexString(ins.ArgData)}");
            }
            break;
        case "text-info":
            var texts=new List<object>();
            foreach(var file in Directory.GetFiles(Path.Combine(args[1],"msg","zhocn"),"*.msgbnd*"))
            foreach(var entry in BND4.Read(file).Files)
                if(entry.Name.EndsWith(".fmg",StringComparison.OrdinalIgnoreCase)) { var fmg=FMG.Read(entry.Bytes); texts.Add(new {entry.ID,entry.Name,entries=fmg.Entries.Select(e=>new{e.ID,e.Text})}); }
            File.WriteAllText(args[2],JsonSerializer.Serialize(texts,new JsonSerializerOptions{WriteIndented=true}));
            break;
        case "warp-info":
            var warps=new List<object>();
            foreach(var entry in BND4.Read(args[1]).Files.Where(f=>f.Name.Contains("BonfireWarp")))
            {
                byte[] bytes=DCX.Is(entry.Bytes)?DCX.Decompress(entry.Bytes):entry.Bytes;
                var param=PARAM.Read(bytes);
                foreach(var row in param.Rows)
                {
                    int length=param.Rows.Where(r=>r.DataOffset>row.DataOffset).Select(r=>(int)(r.DataOffset-row.DataOffset)).DefaultIfEmpty(64).Min();length=Math.Min(length,128);
                    length=Math.Max(0,Math.Min(length,bytes.Length-(int)row.DataOffset));
                    int[] values=Enumerable.Range(0,length/4).Select(i=>BitConverter.ToInt32(bytes,(int)row.DataOffset+i*4)).ToArray();
                    warps.Add(new {paramName=entry.Name,row.ID,row.Name,values});
                }
            }
            File.WriteAllText(args[2],JsonSerializer.Serialize(warps,new JsonSerializerOptions{WriteIndented=true}));break;
        case "boss-data":
            var bossData=new List<object>();
            foreach(var mapFile in Directory.GetFiles(Path.Combine(args[1],"map","mapstudio"),"m*_00_00.msb.dcx")){
                var bossMap=MSBS.Read(mapFile);string mapId=Path.GetFileName(mapFile).Replace(".msb.dcx","");
                var eventPath=Path.Combine(args[1],"event",mapId+".emevd.dcx");
                var scripts=File.Exists(eventPath)?EMEVD.Read(eventPath):null;
                bossData.Add(new{mapId,enemies=bossMap.Parts.GetEntries().OfType<MSBS.Part.EnemyBase>().Where(p=>p.EntityID>0).Select(p=>new{p.EntityID,p.Name,p.ModelName,p.NPCParamID,x=p.Position.X,y=p.Position.Y,z=p.Position.Z}),
                    events=scripts?.Events.Select(ev=>new{ev.ID,instructions=ev.Instructions.Select(ins=>new{ins.Bank,ins.ID,hex=Convert.ToHexString(ins.ArgData)}),parameters=ev.Parameters})});
            }
            var commonPath=Path.Combine(args[1],"event","common_func.emevd.dcx");
            if(File.Exists(commonPath)){var scripts=EMEVD.Read(commonPath);bossData.Add(new{mapId="common_func",events=scripts.Events.Select(ev=>new{ev.ID,instructions=ev.Instructions.Select(ins=>new{ins.Bank,ins.ID,hex=Convert.ToHexString(ins.ArgData)}),parameters=ev.Parameters})});}
            File.WriteAllText(args[2],JsonSerializer.Serialize(bossData,new JsonSerializerOptions{WriteIndented=true}));break;
        default: throw new ArgumentException("Unknown command");
    }
}
catch (Exception error) { Console.Error.WriteLine(error); Environment.ExitCode = 1; }

static void Extract(string game, string output, string resources, string[] prefixes)
{
    output = Path.GetFullPath(output) + Path.DirectorySeparatorChar;
    if (output.StartsWith(Path.GetFullPath(game) + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase))
        throw new ArgumentException("Extraction output must be outside the game directory.");
    Directory.CreateDirectory(output);
    var keys = JsonSerializer.Deserialize<Dictionary<string, string>>(File.ReadAllText(Path.Combine(resources, "sekiro-keys.json")))!;
    var names = new Dictionary<ulong,string>();
    foreach (string line in File.ReadLines(Path.Combine(resources,"SekiroDictionary.txt")))
    {
        string path = line.Trim().Replace('\\','/').ToLowerInvariant();
        if (!path.StartsWith('/')) continue;
        uint hash=0; foreach(char c in path) hash=unchecked(hash*37+c);
        names[hash]=path;
    }
    int total=0; long size=0;
    foreach (string archive in new[] {"Data1","Data2","Data3","Data4","Data5"})
    {
        Console.WriteLine($"Reading {archive} index...");
        byte[] index=DecryptIndex(Path.Combine(game,archive+".bhd"),keys[archive]);
        using var indexStream=new MemoryStream(index);
        var bhd=BHD5.Read(indexStream,BHD5.Game.DarkSouls3);
        using var stream=File.OpenRead(Path.Combine(game,archive+".bdt"));
        int count=0;
        foreach(var entry in bhd.Buckets.SelectMany(x=>x))
        {
            if(!names.TryGetValue(entry.FileNameHash,out string? name)) continue;
            if(prefixes.Length>0 && !prefixes.Any(prefix=>name.StartsWith(prefix,StringComparison.OrdinalIgnoreCase))) continue;
            string target=Path.GetFullPath(Path.Combine(output,name.TrimStart('/').Replace('/',Path.DirectorySeparatorChar)));
            if(!target.StartsWith(output,StringComparison.OrdinalIgnoreCase)) throw new InvalidDataException("Path escapes output");
            if(File.Exists(target)) continue;
            var data=entry.ReadFile(stream);
            Directory.CreateDirectory(Path.GetDirectoryName(target)!);
            File.WriteAllBytes(target,data); count++; total++; size+=data.Length;
            if(count%100==0) Console.WriteLine($"  {count} files extracted from {archive}");
        }
        Console.WriteLine($"{archive}: {count} files");
    }
    Console.WriteLine($"Extracted {total} files, {size/1048576.0:F1} MiB. Original game unchanged.");
}

static byte[] DecryptIndex(string path,string pem)
{
    byte[] data=File.ReadAllBytes(path);
    if(data.AsSpan(0,4).SequenceEqual("BHD5"u8)) return data;
    using var rsa=RSA.Create(); rsa.ImportFromPem(pem);
    var key=rsa.ExportParameters(false);
    var n=new BigInteger(key.Modulus!,true,true); var e=new BigInteger(key.Exponent!,true,true);
    int block=key.Modulus!.Length;
    if(data.Length%block!=0) throw new InvalidDataException("Truncated RSA index");
    using var result=new MemoryStream();
    for(int i=0;i<data.Length;i+=block)
    {
        var value=BigInteger.ModPow(new BigInteger(data.AsSpan(i,block),true,true),e,n).ToByteArray(true,true);
        if(value.Length>block-1) throw new InvalidDataException("Unexpected RSA block size");
        result.Write(new byte[block-1-value.Length]); result.Write(value);
    }
    return result.ToArray();
}

static void Inspect(string unpacked,string output)
{
    var maps=new List<object>();
    foreach(string file in Directory.GetFiles(Path.Combine(unpacked,"map","mapstudio"),"*.msb*"))
    {
        var map=MSBS.Read(file);
        var objects=map.Parts.Objects.Select(p=>new {p.Name,p.ModelName,p.EntityID,x=p.Position.X,y=p.Position.Y,z=p.Position.Z}).ToArray();
        var offsets=map.Events.MapOffsets.Select(x=>new {x.Name,x.Position,x.Degree}).ToArray();
        maps.Add(new {map=Path.GetFileName(file),geometry=map.Parts.MapPieces.Count,offsets,objects,
            pieces=map.Parts.MapPieces.Take(12).Select(p=>new{p.Name,p.ModelName,p.Position,p.Rotation,p.Scale}),
            players=map.Parts.Players.Select(p=>new{p.Name,p.EntityID,x=p.Position.X,y=p.Position.Y,z=p.Position.Z})});
        Console.WriteLine($"{Path.GetFileName(file)}: {map.Parts.MapPieces.Count} map pieces, {objects.Length} objects");
    }
    File.WriteAllText(output,JsonSerializer.Serialize(maps,new JsonSerializerOptions{WriteIndented=true,IncludeFields=true}));
}
