using System.Drawing.Imaging;
using System.Numerics;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Text.RegularExpressions;
using SoulsFormats;

static class Baker
{
    public static void Run(string unpacked,string mapId,string output,int size)
    {
        if(size<256 || size>8192) throw new ArgumentOutOfRangeException(nameof(size));
        Directory.CreateDirectory(output);
        var map=MSBS.Read(Path.Combine(unpacked,"map","mapstudio",mapId+".msb.dcx"));
        var anchors=map.Parts.Players.Select(p=>p.Position)
            .Concat(map.Parts.Enemies.Where(p=>p.EntityID>0).Select(p=>p.Position))
            .Concat(map.Parts.Objects.Where(p=>p.EntityID>0).Select(p=>p.Position)).ToArray();
        float minX=anchors.Min(p=>p.X)-55,maxX=anchors.Max(p=>p.X)+55;
        float minZ=anchors.Min(p=>p.Z)-55,maxZ=anchors.Max(p=>p.Z)+55;
        float span=Math.Max(maxX-minX,maxZ-minZ);
        float cx=(minX+maxX)/2,cz=(minZ+maxZ)/2;
        minX=cx-span/2; maxX=cx+span/2; minZ=cz-span/2; maxZ=cz+span/2;
        var bounds=new Bounds(minX,maxX,minZ,maxZ,size);
        var layers=new List<Surface>{new(size,float.PositiveInfinity,"地表总览")};
        if(mapId=="m11_01_00_00")
            foreach(var (ceiling,name) in new[]{(-15f,"低层高度切片"),(35f,"武士候命室高度切片"),(45f,"道场高度切片"),(52f,"神子居室高度切片")})
                layers.Add(new(size,ceiling,name));
        var groups=map.Parts.MapPieces.GroupBy(p=>p.ModelName).ToDictionary(g=>g.Key,g=>g.ToArray());
        long triangles=0; int instances=0; var seen=new HashSet<string>();
        var materials=new Dictionary<string,int>();
        foreach(string file in Directory.GetFiles(Path.Combine(unpacked,"map",mapId),"*.mapbnd.dcx"))
        {
            string number=Path.GetFileName(file).Substring(mapId.Length+1,6),modelName="m"+number;
            if(!groups.TryGetValue(modelName,out var pieces)) continue;
            var binder=BND4.Read(file);
            var data=binder.Files.FirstOrDefault(f=>f.Name.EndsWith(number+".flver",StringComparison.OrdinalIgnoreCase));
            if(data==null) continue;
            FLVER2 model;
            try {model=FLVER2.Read(data.Bytes);} catch(Exception e){throw new InvalidDataException("Could not read "+file,e);}
            seen.Add(modelName);
            foreach(var part in pieces)
            {
                var radians=part.Rotation*(MathF.PI/180f);
                var transform=Matrix4x4.CreateScale(part.Scale)*Matrix4x4.CreateFromYawPitchRoll(radians.Y,radians.X,radians.Z)*Matrix4x4.CreateTranslation(part.Position);
                instances++;
                foreach(var mesh in model.Meshes)
                {
                    var material=model.Materials[mesh.MaterialIndex];
                    string shader=Path.GetFileNameWithoutExtension(material.MTD).ToLowerInvariant();
                    materials[shader]=materials.GetValueOrDefault(shader)+1;
                    if(Regex.IsMatch(shader,@"shadow|sky|leaf|leaves|grass|tree|branch|bamboo|farview|decal")) continue;
                    var faces=mesh.FaceSets.FirstOrDefault(f=>f.Flags==FLVER2.FaceSet.FSFlags.None)
                        ?? mesh.FaceSets.FirstOrDefault(f=>(f.Flags&FLVER2.FaceSet.FSFlags.MotionBlur)==0);
                    if(faces==null) continue;
                    var indices=faces.Triangulate(true);
                    var vertices=mesh.Vertices.Select(v=>Vector3.Transform(v.Position,transform)).ToArray();
                    int type=Classify(shader);
                    for(int i=0;i+2<indices.Count;i+=3)
                    {
                        if((uint)indices[i]>=(uint)vertices.Length || (uint)indices[i+1]>=(uint)vertices.Length || (uint)indices[i+2]>=(uint)vertices.Length) continue;
                        var a=vertices[indices[i]];var b=vertices[indices[i+1]];var c=vertices[indices[i+2]];
                        foreach(var layer in layers) Raster(layer,bounds,a,b,c,type);
                        triangles++;
                    }
                }
            }
            if(seen.Count%100==0) Console.WriteLine($"{mapId}: {seen.Count} models, {triangles:N0} triangles");
        }
        if(seen.Count==0) throw new InvalidDataException("No model geometry loaded");
        foreach(var (layer,index) in layers.Select((l,i)=>(l,i)))
        {
            Save(layer,bounds,Path.Combine(output,$"layer-{index}.png"));
            using var heights=new BinaryWriter(File.Create(Path.Combine(output,$"layer-{index}.heights")));
            foreach(float h in layer.Height) heights.Write(h);
        }
        var flags=new Dictionary<int,int>();
        string eventPath=Path.Combine(unpacked,"event",mapId+".emevd.dcx");
        if(File.Exists(eventPath))
            foreach(var ev in EMEVD.Read(eventPath).Events) foreach(var ins in ev.Instructions)
                if(ins.Bank==2009 && ins.ID==3 && ins.ArgData.Length>=8)
                    flags[BitConverter.ToInt32(ins.ArgData,4)]=BitConverter.ToInt32(ins.ArgData,0);
        var idols=ReadIdols(unpacked,map,flags);
        var manifest=new{
            schemaVersion=1,id=mapId,name=MapName(mapId),quality="geometry-preview",
            bounds=new{minX,maxX,minZ,maxZ},width=size,height=size,
            coordinates="MSBS instance transforms; runtime calibration pending",
            layers=layers.Select((l,i)=>new{id=i,name=l.Name,image=$"layer-{i}.png",heightFile=$"layer-{i}.heights",ceiling=float.IsFinite(l.Ceiling)?(float?)l.Ceiling:null,experimental=i>0}),
            idols,bosses=ReadBosses(unpacked,map,mapId),stats=new{models=seen.Count,instances,triangles,missingModels=groups.Keys.Where(x=>!seen.Contains(x)).ToArray()}
        };
        File.WriteAllText(Path.Combine(output,"map.json"),JsonSerializer.Serialize(manifest,new JsonSerializerOptions{WriteIndented=true}));
        File.WriteAllText(Path.Combine(output,"materials.json"),JsonSerializer.Serialize(materials.OrderByDescending(x=>x.Value),new JsonSerializerOptions{WriteIndented=true}));
        Console.WriteLine($"Baked {mapId}: {seen.Count}/{groups.Count} models, {triangles:N0} triangles, {idols.Count} idols, {layers.Count} layers, {span/size:F3} world units/pixel");
    }

    record Bounds(float MinX,float MaxX,float MinZ,float MaxZ,int Size)
    {
        public Vector2 Project(Vector3 v)=>new((v.X-MinX)/(MaxX-MinX)*(Size-1),(MaxZ-v.Z)/(MaxZ-MinZ)*(Size-1));
    }
    class Surface(int size,float ceiling,string name)
    {
        public int Size=size;public float Ceiling=ceiling;public string Name=name;
        public float[] Height=Enumerable.Repeat(float.NegativeInfinity,size*size).ToArray();
        public byte[] Type=new byte[size*size]; public byte[] Light=new byte[size*size];
    }
    static int Classify(string shader)
    {
        if(Regex.IsMatch(shader,@"water|river|pond|lake")) return 2;
        if(Regex.IsMatch(shader,@"roof|kawara")) return 3;
        if(Regex.IsMatch(shader,@"road|path|floor|wood|plank|bridge|tatami")) return 4;
        if(Regex.IsMatch(shader,@"snow")) return 5;
        if(Regex.IsMatch(shader,@"rock|stone|wall|cliff")) return 6;
        if(Regex.IsMatch(shader,@"ground|terrain|soil|mud|mountain|grass")) return 1;
        return 0;
    }
    static float Edge(Vector2 a,Vector2 b,Vector2 p)=>(p.X-a.X)*(b.Y-a.Y)-(p.Y-a.Y)*(b.X-a.X);
    static void Raster(Surface surface,Bounds bounds,Vector3 a,Vector3 b,Vector3 c,int type)
    {
        if(a.Y>surface.Ceiling && b.Y>surface.Ceiling && c.Y>surface.Ceiling) return;
        var pa=bounds.Project(a);var pb=bounds.Project(b);var pc=bounds.Project(c);
        float area=Edge(pa,pb,pc);if(Math.Abs(area)<.001f) return;
        int minX=Math.Max(0,(int)MathF.Floor(Math.Min(pa.X,Math.Min(pb.X,pc.X)))),maxX=Math.Min(surface.Size-1,(int)MathF.Ceiling(Math.Max(pa.X,Math.Max(pb.X,pc.X))));
        int minY=Math.Max(0,(int)MathF.Floor(Math.Min(pa.Y,Math.Min(pb.Y,pc.Y)))),maxY=Math.Min(surface.Size-1,(int)MathF.Ceiling(Math.Max(pa.Y,Math.Max(pb.Y,pc.Y))));
        var normal=Vector3.Normalize(Vector3.Cross(b-a,c-a)); if(normal.Y<0) normal=-normal;
        float light=.40f+.60f*Math.Max(0,Vector3.Dot(normal,Vector3.Normalize(new(-.5f,1f,-.4f))));
        for(int y=minY;y<=maxY;y++) for(int x=minX;x<=maxX;x++)
        {
            var p=new Vector2(x+.5f,y+.5f);
            float w0=Edge(pb,pc,p)/area,w1=Edge(pc,pa,p)/area,w2=1-w0-w1;
            if(w0<-.0001f || w1<-.0001f || w2<-.0001f) continue;
            float h=w0*a.Y+w1*b.Y+w2*c.Y;
            int index=y*surface.Size+x;
            if(h>surface.Ceiling || h<surface.Height[index]) continue;
            surface.Height[index]=h;surface.Type[index]=(byte)type;surface.Light[index]=(byte)(light*255);
        }
    }
    static unsafe void Save(Surface layer,Bounds bounds,string output)
    {
        using var bitmap=new Bitmap(layer.Size,layer.Size,PixelFormat.Format32bppArgb);
        var data=bitmap.LockBits(new(0,0,layer.Size,layer.Size),ImageLockMode.WriteOnly,PixelFormat.Format32bppArgb);
        try
        {
            for(int y=0;y<layer.Size;y++) for(int x=0;x<layer.Size;x++)
            {
                int i=y*layer.Size+x;float h=layer.Height[i];
                var pixel=(byte*)data.Scan0+y*data.Stride+x*4;
                if(!float.IsFinite(h)){pixel[0]=28;pixel[1]=30;pixel[2]=27;pixel[3]=255;continue;}
                var (r,g,b)=layer.Type[i] switch{
                    1=>(112,123,91),2=>(58,113,133),3=>(85,97,106),4=>(162,135,98),5=>(210,213,202),6=>(149,143,126),_=>(138,133,112)};
                float light=layer.Light[i]/255f;
                float rise=Math.Clamp((h+150)/350f,0,1);
                light*=.82f+.22f*rise;
                float maxDifference=0;bool contour=false;
                foreach(var (nx,ny) in new[]{(x+1,y),(x,y+1)})
                    if(nx<layer.Size&&ny<layer.Size){float nh=layer.Height[ny*layer.Size+nx];if(float.IsFinite(nh)){maxDifference=Math.Max(maxDifference,Math.Abs(h-nh));contour|=MathF.Floor(h/10)!=MathF.Floor(nh/10);}}
                if(maxDifference>3) light*=.56f;
                else if(contour && layer.Type[i]!=2) light*=.84f;
                pixel[2]=(byte)Math.Clamp(r*light,0,255);pixel[1]=(byte)Math.Clamp(g*light,0,255);pixel[0]=(byte)Math.Clamp(b*light,0,255);pixel[3]=255;
            }
        }
        finally{bitmap.UnlockBits(data);}
        bitmap.Save(output,ImageFormat.Png);
    }
    static string MapName(string id)=>id switch{
        "m10_00_00_00"=>"平田宅邸","m11_00_00_00"=>"苇名城 城邑","m11_01_00_00"=>"苇名城 主城","m11_02_00_00"=>"苇名城 贮水城区",
        "m13_00_00_00"=>"地牢","m15_00_00_00"=>"苇名之底","m17_00_00_00"=>"坠落之谷","m20_00_00_00"=>"金刚山 仙峰寺","m25_00_00_00"=>"源之宫",_=>id};
    static string IdolName(int id)=>Names.GetValueOrDefault(id,$"鬼佛 {id}");
    record IdolData(int entityId,string name,float x,float y,float z,int unlockFlag,int disabledFlag,string state);
    record BossData(int entityId,string name,float x,float y,float z,int deathFlag,string kind,string state);
    static List<BossData> ReadBosses(string unpacked,MSBS map,string mapId){
        string catalogFile=Path.Combine(AppContext.BaseDirectory,"resources","boss-catalog.json");
        if(!File.Exists(catalogFile))throw new FileNotFoundException("Missing resources/boss-catalog.json. Copy the source resources into the builder output.",catalogFile);
        var catalog=JsonNode.Parse(File.ReadAllText(catalogFile))!["bosses"]!.AsArray();
        var names=new Dictionary<int,string>();
        foreach(string messages in Directory.GetFiles(Path.Combine(unpacked,"msg","zhocn"),"*.msgbnd.dcx"))
            foreach(var file in BND4.Read(messages).Files.Where(f=>f.Name.EndsWith("NPC名.fmg")))foreach(var entry in FMG.Read(file.Bytes).Entries)if(entry.Text!=null)names[entry.ID]=entry.Text;
        var characters=map.Parts.GetEntries().OfType<MSBS.Part.EnemyBase>().GroupBy(p=>p.EntityID).ToDictionary(g=>g.Key,g=>g.First());
        var result=new List<BossData>();
        foreach(var record in catalog.Where(b=>b!["mapId"]!.GetValue<string>()==mapId)){
            int entity=record!["entityId"]!.GetValue<int>(),nameId=record["npcNameId"]!.GetValue<int>(),flag=record["deathFlag"]!.GetValue<int>();
            if(!characters.TryGetValue(entity,out var character))throw new InvalidDataException($"Boss entity {entity} missing in {mapId}");
            if(flag<=0)throw new InvalidDataException($"Invalid boss clear flag {entity}");
            if(!names.TryGetValue(nameId,out string bossName)||string.IsNullOrWhiteSpace(bossName))throw new InvalidDataException($"Boss name {nameId} missing in game FMG");
            string name=bossName+(record["nameSuffix"]?.GetValue<string>()??"");
            result.Add(new(entity,name,character.Position.X,character.Position.Y,character.Position.Z,flag,record["kind"]!.GetValue<string>(),"unknown"));
        }
        return result;
    }
    static List<IdolData> ReadIdols(string unpacked,MSBS map,Dictionary<int,int> registered)
    {
        var text=new Dictionary<int,string>();
        string messages=Path.Combine(unpacked,"msg","zhocn","menu.msgbnd.dcx");
        if(File.Exists(messages))foreach(var file in BND4.Read(messages).Files.Where(f=>f.Name.EndsWith("NTC_メニューテキスト.fmg")))
            foreach(var entry in FMG.Read(file.Bytes).Entries)if(entry.Text!=null)text[entry.ID]=entry.Text;
        var warps=new Dictionary<int,(string Name,int Available,int Active)>();
        string gameParam=Path.Combine(unpacked,"param","gameparam","gameparam.parambnd.dcx");
        if(File.Exists(gameParam))foreach(var file in BND4.Read(gameParam).Files.Where(f=>f.Name.EndsWith("BonfireWarpParam.param")))
        {
            byte[] bytes=DCX.Is(file.Bytes)?DCX.Decompress(file.Bytes):file.Bytes;
            foreach(var row in PARAM.Read(bytes).Rows)
            {
                if(row.DataOffset<=0||row.DataOffset+28>bytes.Length)continue;
                int available=BitConverter.ToInt32(bytes,(int)row.DataOffset),entity=BitConverter.ToInt32(bytes,(int)row.DataOffset+4),nameId=BitConverter.ToInt32(bytes,(int)row.DataOffset+8),active=BitConverter.ToInt32(bytes,(int)row.DataOffset+24);
                if(entity>0)warps[entity]=(text.GetValueOrDefault(nameId,IdolName(entity)),available,active);
            }
        }
        return map.Parts.GetEntries().Where(p=>p.ModelName=="o005000" || (p.EntityID>0 && (registered.ContainsKey(p.EntityID)||warps.ContainsKey(p.EntityID))))
            .GroupBy(p=>p.EntityID).Select(g=>g.First()).Select(p=>{
                var data=warps.GetValueOrDefault(p.EntityID,(IdolName(p.EntityID),registered.GetValueOrDefault(p.EntityID),0));
                return new IdolData(p.EntityID,data.Item1,p.Position.X,p.Position.Y,p.Position.Z,data.Item2,data.Item3,"unknown");
            }).ToList();
    }
    public static void Refresh(string unpacked,string folder)
    {
        string file=Path.Combine(folder,"map.json");var metadata=JsonNode.Parse(File.ReadAllText(file))!;string id=metadata["id"]!.GetValue<string>();
        var map=MSBS.Read(Path.Combine(unpacked,"map","mapstudio",id+".msb.dcx"));var registered=new Dictionary<int,int>();
        string events=Path.Combine(unpacked,"event",id+".emevd.dcx");
        if(File.Exists(events))foreach(var ev in EMEVD.Read(events).Events)foreach(var ins in ev.Instructions)
            if(ins.Bank==2009&&ins.ID==3&&ins.ArgData.Length>=8)registered[BitConverter.ToInt32(ins.ArgData,4)]=BitConverter.ToInt32(ins.ArgData,0);
        var idols=ReadIdols(unpacked,map,registered);metadata["idols"]=JsonSerializer.SerializeToNode(idols);metadata["name"]=MapName(id);metadata["bosses"]=JsonSerializer.SerializeToNode(ReadBosses(unpacked,map,id));
        File.WriteAllText(file,metadata.ToJsonString(new JsonSerializerOptions{WriteIndented=true}));
        Console.WriteLine($"Refreshed {id}: {idols.Count} idols, names from game FMG and BonfireWarpParam");
    }
    static readonly Dictionary<int,string> Names=new(){
        [1101950]="破旧寺院",[1101951]="城邑外围 城门道",[1101952]="城邑外围 虎口阶梯",[1101953]="桥下山谷",[1101954]="苇名城 正门城楼",[1101955]="苇名城 正门",[1101956]="苇名城 城邑",[1101957]="怨恨之火",[1101959]="苇名城 正门（剧情）",[1101960]="城邑外围（剧情）",
        [1111950]="苇名城 主城",[1111951]="天守阁上层 武士候命室",[1111952]="天守阁望楼",[1111953]="天守阁上层 神子居室",[1111954]="白蛇神社",[1111955]="地牢入口",[1111956]="遗冢",[1111957]="天守阁上层 苇名流道场",[1111958]="天守阁望楼（剧情）",[1121950]="暗道前",[1121951]="苇名城 贮水城区",[1121952]="暗道前（剧情）"};
    public static void SelfTest()
    {
        var bounds=new Bounds(-10,10,-10,10,101);var layer=new Surface(101,float.PositiveInfinity,"test");
        Raster(layer,bounds,new(-8,2,-8),new(8,2,-8),new(0,2,8),1);
        int center=50*101+50;
        if(Math.Abs(layer.Height[center]-2)>.01f) throw new Exception("World projection/raster triangle failed");
        Raster(layer,bounds,new(-8,7,-8),new(8,7,-8),new(0,7,8),4);
        if(Math.Abs(layer.Height[center]-7)>.01f) throw new Exception("Top-surface depth failed");
        var slice=new Surface(101,4,"slice");
        Raster(slice,bounds,new(-8,7,-8),new(8,7,-8),new(0,7,8),4);
        if(float.IsFinite(slice.Height[center])) throw new Exception("Upper-floor clipping failed");
        Raster(slice,bounds,new(-8,2,-8),new(8,2,-8),new(0,2,8),1);
        if(Math.Abs(slice.Height[center]-2)>.01f) throw new Exception("Lower-floor exposure failed");
        var corner=bounds.Project(new(-10,0,10));if(corner.Length()>.001f) throw new Exception("North-up map orientation failed");
        Console.WriteLine("PASS: projection, top-surface depth, height slicing, map orientation");
    }
}
