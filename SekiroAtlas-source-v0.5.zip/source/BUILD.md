# 构建和制图

原生插件使用 C++17、Dear ImGui、MinHook、nlohmann/json 与 Windows DirectX 11。第三方源码已经放在 `third_party`，其许可证保留在对应目录与 `THIRD_PARTY.md` 中。

本次编译使用 Zig `0.12.0-dev.1286+cc394431a` 的 Windows x64 包；编译器没有放入交付包。也可以将项目移植到 Visual Studio 的 x64 C++ 工具链。

在 PowerShell 中构建原生程序：

```powershell
.\Build.ps1 -ZigPath 'C:\path\to\zig.exe'
```

输出位于源代码目录的上一级：`AtlasMod.dll`、`StartAtlas.exe`、`AtlasTestHost.exe`。构建缓存默认位于系统临时目录，可用 `-BuildDirectory` 修改。

**地图生成器**

需要 .NET 10 SDK 和 Windows 桌面运行时。生成器包含 SoulsFormats 源码和预置 ZstdSharp 程序集，不需要从 NuGet 获取额外包：

地图生成器组合使用 GPL-3.0 的 SoulsFormats，相关源代码与许可均已提供。原生游戏绘制 DLL 与生成器是独立程序，原生 DLL 不链接 SoulsFormats。

```powershell
dotnet build .\tools\AtlasBuilder\AtlasBuilder.csproj -c Release -o .\builder
```

将用户本机《只狼》目录中的 `oo2core_6_win64.dll` 复制到本地 `builder` 目录，以便读取 Oodle 压缩数据。Oodle 不随这个测试包提供。

下面以独立的工作目录为例。提取目录必须在游戏目录之外，工具会检查这一点：

```powershell
dotnet .\builder\AtlasBuilder.dll extract 'G:\SteamLibrary\steamapps\common\Sekiro' 'C:\SekiroAtlasWork\unpacked' .\resources '/map/mapstudio/' '/event/' '/msg/zhocn/' '/param/gameparam/' '/map/m11_00_00_00/'
dotnet .\builder\AtlasBuilder.dll bake 'C:\SekiroAtlasWork\unpacked' 'm11_00_00_00' '..\maps\m11_00_00_00' 2048
dotnet .\builder\AtlasBuilder.dll self-test
```

其他区域的模型目录使用对应地图 ID。所有主要区域：`m10_00_00_00`、`m11_00_00_00`、`m11_01_00_00`、`m11_02_00_00`、`m13_00_00_00`、`m15_00_00_00`、`m17_00_00_00`、`m20_00_00_00`、`m25_00_00_00`。

`refresh UNPACKED MAP_FOLDER` 只更新该区域的鬼佛名称与标记元数据，不重新绘制底图。

底图采用 MSBS 实例变换和 FLVER 三角面投影，去掉部分植被、阴影和远景材质，进行深度选择、材质分类、高度轮廓和几何明暗绘制。`map.json` 存储坐标范围、图层和鬼佛；`layer-*.heights` 为小端 float32 高度栅格。运行时仅在试验自动切层需要时加载高度栅格。

**验证**

运行 `AtlasTestHost.exe` 会在隐藏的独立 DX11 窗口中加载同一 DLL，以明确标注的模拟站位绘制地图，检查分辨率切换、Win32 快捷键、每次打开的 10 倍玩家居中视图、鬼佛图标命中、传送状态限制和重复请求拒绝。预览模式的传送不会调用真实游戏函数。截图为 `preview-*.bmp`，结果为 `render-test.json`。这不替代游戏内实测。

请在游戏未加载此目录的 DLL 时运行测试程序，否则测试会覆盖同目录的日志和运行状态。可把二进制、配置和 maps 复制到独立工作目录测试。

待完成的游戏内检查：各区域实际站位和朝向核验、钩索时图层稳定性、死亡和传送期间指针失效处理、暂停菜单与输入接管、Steam 全屏与窗口模式、真实帧时间开销。
