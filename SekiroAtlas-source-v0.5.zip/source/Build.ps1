param([Parameter(Mandatory=$true)][string]$ZigPath,[string]$BuildDirectory=(Join-Path ([IO.Path]::GetTempPath()) 'SekiroAtlas-build'))
$ErrorActionPreference='Stop'
$compiler=(Resolve-Path -LiteralPath $ZigPath).Path
$compilerRoot=Split-Path -Parent $compiler
$source=$PSScriptRoot
$output=Split-Path -Parent $source
$third=Join-Path $source 'third_party'
New-Item -ItemType Directory -Force -Path $BuildDirectory | Out-Null
$env:ZIG_GLOBAL_CACHE_DIR=Join-Path $BuildDirectory 'zig-cache'
$env:ZIG_LOCAL_CACHE_DIR=Join-Path $BuildDirectory 'zig-local'
$objects=@()
foreach($file in @('buffer.c','hook.c','trampoline.c','hde\hde64.c')){
    $object=Join-Path $BuildDirectory ([IO.Path]::GetFileNameWithoutExtension($file)+'.o')
    & $compiler cc -target x86_64-windows-gnu -O2 -I "$third\minhook\include" -c "$third\minhook\src\$file" -o $object
    if($LASTEXITCODE -ne 0){throw "MinHook compile failed: $file"}
    $objects+=$object
}
foreach($file in @('_create_locale.c','_free_locale.c')){
    $compatibility=Join-Path $compilerRoot "lib\libc\mingw\misc\$file"
    if(Test-Path -LiteralPath $compatibility){
        $object=Join-Path $BuildDirectory ([IO.Path]::GetFileNameWithoutExtension($file)+'.o')
        & $compiler cc -target x86_64-windows-gnu -O2 -D__LIBMSVCRT_OS__ -I "$compilerRoot\lib\libc\mingw\include" -c $compatibility -o $object
        if($LASTEXITCODE -ne 0){throw "CRT compatibility compile failed: $file"}
        $objects+=$object
    }
}
$files=@("$source\native\Atlas.cpp","$third\imgui\imgui.cpp","$third\imgui\imgui_draw.cpp","$third\imgui\imgui_tables.cpp","$third\imgui\imgui_widgets.cpp","$third\imgui\backends\imgui_impl_win32.cpp","$third\imgui\backends\imgui_impl_dx11.cpp")
& $compiler c++ -target x86_64-windows-gnu -std=c++17 -O2 -shared -DUNICODE -D_UNICODE -DDIRECTINPUT_VERSION=0x0800 -I $third -I "$third\imgui" -I "$third\minhook\include" @files @objects -ld3d11 -ldxgi -ld3dcompiler_47 -ldwmapi -ldinput8 -luser32 -lgdi32 -lole32 -luuid -o "$output\AtlasMod.dll"
if($LASTEXITCODE -ne 0){throw 'Atlas DLL compile failed'}
& $compiler c++ -target x86_64-windows-gnu -std=c++17 -O2 -DUNICODE -D_UNICODE "$source\native\Launcher.cpp" '-Wl,--subsystem,windows' -luser32 -lkernel32 -o "$output\StartAtlas.exe"
if($LASTEXITCODE -ne 0){throw 'Launcher compile failed'}
& $compiler c++ -target x86_64-windows-gnu -std=c++17 -O2 -DUNICODE -D_UNICODE "$source\native\TestHost.cpp" @objects -ld3d11 -ldxgi -luser32 -luuid -o "$output\AtlasTestHost.exe"
if($LASTEXITCODE -ne 0){throw 'Test host compile failed'}
Write-Output 'Built AtlasMod.dll, StartAtlas.exe, AtlasTestHost.exe'
