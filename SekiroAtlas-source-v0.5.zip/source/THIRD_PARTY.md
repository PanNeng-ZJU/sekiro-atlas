# 第三方来源

本项目保留了以下组件的源码或程序集，其许可证随对应目录或 `third_party/LICENSE-*` 文件提供。

| 组件 | 来源 | 本次使用 |
|---|---|---|
| Dear ImGui | https://github.com/ocornut/imgui | 头文件版本 1.93.0 WIP，快照已随源码固定；MIT |
| MinHook | https://github.com/TsudaKageyu/minhook | x64 DXGI 与输入接口 Hook；BSD 风格许可证及 HDE 许可见 LICENSE.txt |
| nlohmann/json | https://github.com/nlohmann/json/tree/v3.11.3 | v3.11.3 单文件头；MIT，许可在头文件开头 |
| SoulsFormats | https://github.com/JKAnderson/SoulsFormats | 归档仓库源码，读取 Sekiro MSBS、FLVER、BHD5、BND4、FMG、EMEVD、PARAM；本次快照根目录 LICENSE 为 GPL-3.0，已原样保留 |
| ZstdSharp.Port | https://www.nuget.org/packages/ZstdSharp.Port/0.8.1 | 0.8.1 net8.0 程序集，用于 SoulsFormats 编译；MIT |
| SekiroTool | https://github.com/borgCode/SekiroTool | 玩家、区域与事件管理器结构、特征签名、区域索引、鬼佛传送调用参考；MIT 许可随包提供 |
| Paramdex | https://github.com/soulsmods/Paramdex/blob/master/SDT/Defs/BonfireWarpParam.xml | 只参考 Sekiro 参数定义，核对解锁和灰显条件旗标的含义；未打包该文件 |
| DarkScript3 | https://github.com/AinTunez/DarkScript3 | 只参考 EMEVD 指令定义，检查 Boss 血条、击杀与事件旗标；未打包其源码 |
| SoulsRandomizers | https://github.com/thefifthmatt/SoulsRandomizers | Boss 分类和名称 ID 的交叉参考；交付的精简目录由本项目编写，坐标和旗标另与用户本机游戏文件核对 |
| UXM Selective Unpack | https://github.com/Nordgaren/UXM-Selective-Unpack | Sekiro 文件路径索引与资源包 RSA 公钥来源；提取逻辑为本项目编写 |

构建工具是 Zig 0.12.0-dev.1286，来源为 npm 的 `@oven/zig-win32-x64` 平台包，下载时核对了 npm 提供的 SHA-512 integrity。Zig 编译器未放入交付包。该版本的 MinGW CRT locale 兼容源码属于 Public Domain，构建脚本按需从编译器目录编译。

Oodle 压缩库从用户自己的游戏安装中读取，不在此交付包中重新分发。生成的地图底图及游戏中文名称来自用户本机游戏资源；本项目代码的许可不覆盖游戏资源。
