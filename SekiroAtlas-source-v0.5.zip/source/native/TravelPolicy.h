#pragma once
enum class IdolState { Unknown, Locked, Unavailable, Available };
inline IdolState ResolveIdolState(bool metadata,bool readable,bool unlocked,bool disabled){
    if(!metadata||!readable)return IdolState::Unknown;
    if(disabled)return IdolState::Unavailable;
    return unlocked?IdolState::Available:IdolState::Locked;
}
inline bool CanTravel(IdolState state,bool playerReady,bool busy,bool allowLocked=false){
    return (state==IdolState::Available||(allowLocked&&state==IdolState::Locked))&&playerReady&&!busy;
}
