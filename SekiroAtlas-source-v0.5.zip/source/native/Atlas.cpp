#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#define INITGUID
#include <windows.h>
#include <d3d11.h>
#include <dxgi.h>
#include <wincodec.h>
#include <dinput.h>
#include <xinput.h>
#include <filesystem>
#include <fstream>
#include <vector>
#include <string>
#include <cmath>
#include <atomic>
#include <mutex>
#include <algorithm>
#include <nlohmann/json.hpp>
#include <imgui.h>
#include <backends/imgui_impl_win32.h>
#include <backends/imgui_impl_dx11.h>
#include <MinHook.h>
#include "TravelPolicy.h"
#include "GamepadActions.h"

using json=nlohmann::json;
namespace fs=std::filesystem;
static HMODULE selfModule;
static fs::path root;
static ID3D11Device* device=nullptr;
static ID3D11DeviceContext* context=nullptr;
static ID3D11RenderTargetView* target=nullptr;
static IDXGISwapChain* primarySwap=nullptr;
static HWND gameWindow=nullptr;
static WNDPROC originalWndProc=nullptr;
static std::atomic<bool> mapOpen=false,previewMode=false;
static std::atomic<bool> centerOnOpen=false,travelBusy=false,allowLockedTravel=false;
static std::atomic<ULONGLONG> suppressInputUntil=0;
static std::atomic<float> minimapRadius=65.0f;
static std::atomic<unsigned long long> blockedDeviceReads=0,blockedKeyPolls=0,blockedCursorCalls=0;
static uintptr_t gameImageBegin=0,gameImageEnd=0;
static thread_local bool inputBypass=false;
struct InputBypassScope{bool previous=inputBypass;InputBypassScope(){inputBypass=true;}~InputBypassScope(){inputBypass=previous;}};
static std::mutex configLock;
using KeyFn=SHORT(WINAPI*)(int);
using CursorGetFn=BOOL(WINAPI*)(LPPOINT);
using CursorSetFn=BOOL(WINAPI*)(int,int);
using CursorClipFn=BOOL(WINAPI*)(const RECT*);
static KeyFn originalAsyncKey=nullptr,originalKey=nullptr;
static CursorGetFn originalCursorGet=nullptr;
static CursorSetFn originalCursorSet=nullptr;
static CursorClipFn originalCursorClip=nullptr;
static POINT frozenCursor{};
static RECT previousClip{};
static bool clipSaved=false;
static std::atomic<int> previewLarge=-1;
static bool ready=false,uiHidden=false;
static UINT renderWidth=0,renderHeight=0;
static uintptr_t chrGlobal=0,areaGlobal=0;
static uintptr_t eventGlobal=0,menuGlobal=0,warpGlobal=0;
using EventFn=bool(*)(uintptr_t,int,bool);
using WarpFn=void(*)(void*,int,int);
static EventFn getEvent=nullptr;
static WarpFn warpToIdol=nullptr;
static std::string memoryStatus="正在寻找游戏状态";
static std::mutex renderLock;
static json config;
static std::ofstream logFile;
static int displayedMap=-1,layerIndex=0;
static float fullZoom=1.0f,panX=0,panY=0;
static bool automaticLayer=false;
static int selectedIdol=-1,pendingTravelMap=-1,pendingTravelIdol=-1,lastTravelEntity=0;
static unsigned long long warpRequests=0;
static ULONGLONG travelStarted=0;
static bool travelSawLoading=false;
static std::string travelMessage;
static int connectedController=-1;
static ControllerButtons controllerButtons;
static std::atomic<bool> gameChordLatched[4]{};
static unsigned long long controllerActions=0;

struct Idol{int entity=0;std::string name;float x=0,y=0,z=0;int unlockFlag=0,disabledFlag=0;IdolState state=IdolState::Unknown;};
struct Boss{int entity=0;std::string name;float x=0,y=0,z=0;int deathFlag=0,state=-1;};
struct Layer{std::string name;fs::path image,heightFile;float ceiling=INFINITY;ID3D11ShaderResourceView* texture=nullptr;std::vector<float> heights;};
struct Map{std::string id,name;float minX=0,maxX=1,minZ=0,maxZ=1;int width=0,height=0;std::vector<Layer> layers;std::vector<Idol> idols;std::vector<Boss> bosses;};
struct Player{bool valid=false;int map=-1;float x=0,y=0,z=0,angle=0;};
static std::vector<Map> maps;
static Player player;
static void SetMapOpen(bool open){
    if(open&&travelBusy)return;
    if(open&&!mapOpen){
        centerOnOpen=true;
        if(originalCursorGet)originalCursorGet(&frozenCursor);else GetCursorPos(&frozenCursor);
        clipSaved=GetClipCursor(&previousClip)!=FALSE;
        if(!previewMode&&originalCursorClip)originalCursorClip(nullptr);
    }
    if(!open&&mapOpen){
        if(!previewMode&&GetForegroundWindow()==gameWindow){if(originalCursorSet)originalCursorSet(frozenCursor.x,frozenCursor.y);if(clipSaved&&originalCursorClip)originalCursorClip(&previousClip);}
        clipSaved=false;suppressInputUntil=GetTickCount64()+200;
    }
    mapOpen=open;
}
static bool SuppressInput(){return mapOpen||GetTickCount64()<suppressInputUntil.load();}
using PresentFn=HRESULT(STDMETHODCALLTYPE*)(IDXGISwapChain*,UINT,UINT);
using ResizeFn=HRESULT(STDMETHODCALLTYPE*)(IDXGISwapChain*,UINT,UINT,UINT,DXGI_FORMAT,UINT);
using StateFn=HRESULT(STDMETHODCALLTYPE*)(IDirectInputDevice8W*,DWORD,LPVOID);
using DataFn=HRESULT(STDMETHODCALLTYPE*)(IDirectInputDevice8W*,DWORD,LPDIDEVICEOBJECTDATA,LPDWORD,DWORD);
using XInputFn=DWORD(WINAPI*)(DWORD,XINPUT_STATE*);
static PresentFn originalPresent=nullptr;
static ResizeFn originalResize=nullptr;
static StateFn originalStates[8]{};
static DataFn originalDatas[8]{};
static void* stateTargets[8]{};
static void* dataTargets[8]{};
static int stateCount=0,dataCount=0;
static XInputFn originalXInput=nullptr;
static XInputFn xinputOriginals[3]{};
static void* xinputTargets[3]{};
static int xinputCount=0;

static void Log(const std::string& message){if(logFile){logFile<<message<<std::endl;}}
template<class T>static bool Read(uintptr_t address,T& result){SIZE_T got=0;return address>0x10000 && ReadProcessMemory(GetCurrentProcess(),reinterpret_cast<void*>(address),&result,sizeof(T),&got) && got==sizeof(T);}
static uintptr_t Pointer(uintptr_t address){uintptr_t value=0;return Read(address,value)?value:0;}
static float JsonFloat(const json& obj,const char* field,float fallback){return obj.contains(field)&&obj[field].is_number()?obj[field].get<float>():fallback;}
static void SaveConfig(){std::lock_guard<std::mutex> guard(configLock);try{std::ofstream stream(root/L"atlas-config.json");stream<<config.dump(2);}catch(...){Log("Could not save config");}}
static void ChangeMinimapZoom(float factor){float radius=std::clamp(minimapRadius.load()*factor,15.0f,200.0f);minimapRadius=radius;{std::lock_guard<std::mutex> guard(configLock);config["minimapRadius"]=radius;}SaveConfig();}
static void SetAllowLockedTravel(bool enabled){allowLockedTravel=enabled;{std::lock_guard<std::mutex> guard(configLock);config["allowLockedTravel"]=enabled;}SaveConfig();travelMessage.clear();}
static void LoadData(){
    config={{"mapKey",77},{"hideKey",120},{"zoomOutKey",117},{"zoomInKey",118},{"minimapSize",320},{"minimapRadius",65.0},{"opacity",0.93},{"controllerEnabled",true},{"allowLockedTravel",false},{"playerOffsets",json::object()}};
    try{std::ifstream stream(root/L"atlas-config.json");if(stream){json values;stream>>values;config.update(values);}}catch(...){Log("Invalid config; defaults loaded");}
    if(!config["playerOffsets"].is_object())config["playerOffsets"]=json::object();
    if(!config["controllerEnabled"].is_boolean())config["controllerEnabled"]=true;
    if(!config["allowLockedTravel"].is_boolean())config["allowLockedTravel"]=false;
    allowLockedTravel=config["allowLockedTravel"].get<bool>();
    for(const auto& key:{"mapKey","hideKey","zoomOutKey","zoomInKey"})if(!config[key].is_number_integer())config[key]=std::string(key)=="mapKey"?77:std::string(key)=="hideKey"?120:std::string(key)=="zoomOutKey"?117:118;
    config["mapKey"]=std::clamp(config["mapKey"].get<int>(),1,254);config["hideKey"]=std::clamp(config["hideKey"].get<int>(),1,254);
    for(const auto& key:{"minimapSize","minimapRadius","opacity"})if(!config[key].is_number())config[key]=std::string(key)=="minimapSize"?320.0:std::string(key)=="minimapRadius"?65.0:.93;
    minimapRadius=std::clamp(JsonFloat(config,"minimapRadius",65),15.0f,200.0f);
    try{
        for(const auto& directory:fs::directory_iterator(root/L"maps")){
            std::ifstream stream(directory.path()/L"map.json");if(!stream)continue;
            json data;stream>>data;Map map;
            if(data.value("schemaVersion",0)!=1)continue;
            map.id=data.at("id");map.name=data.at("name");
            auto& bounds=data.at("bounds");map.minX=bounds.at("minX");map.maxX=bounds.at("maxX");map.minZ=bounds.at("minZ");map.maxZ=bounds.at("maxZ");
            map.width=data.at("width");map.height=data.at("height");
            if(map.width<1 || map.height<1 || map.width>8192 || map.height>8192 || map.maxX<=map.minX || map.maxZ<=map.minZ)continue;
            for(const auto& l:data.at("layers")){
                Layer layer;layer.name=l.at("name");layer.image=directory.path()/fs::u8path(l.at("image").get<std::string>());
                if(l.contains("ceiling")&&!l["ceiling"].is_null())layer.ceiling=l["ceiling"];
                layer.heightFile=directory.path()/fs::u8path(l.at("heightFile").get<std::string>());
                map.layers.push_back(std::move(layer));
            }
            for(const auto& i:data.at("idols"))map.idols.push_back({i.at("entityId"),i.at("name"),i.at("x"),i.at("y"),i.at("z"),i.value("unlockFlag",i.value("availabilityFlag",0)),i.value("disabledFlag",i.value("activationFlag",0))});
            if(data.contains("bosses"))for(const auto& b:data["bosses"])map.bosses.push_back({b.at("entityId"),b.at("name"),b.at("x"),b.at("y"),b.at("z"),b.at("deathFlag")});
            if(!map.layers.empty())maps.push_back(std::move(map));
        }
        std::sort(maps.begin(),maps.end(),[](const Map& a,const Map& b){return a.id<b.id;});
        Log("Loaded "+std::to_string(maps.size())+" region maps");
    }catch(const std::exception& error){Log(std::string("Map load failure: ")+error.what());}
}
static uintptr_t FindGlobal(const std::vector<unsigned char>& code,uintptr_t start,const std::vector<int>& signature,size_t instruction=0,size_t displacementOffset=3,size_t length=7){
    uintptr_t result=0;
    for(size_t i=0;i+signature.size()<=code.size();i++){
        bool match=true;for(size_t j=0;j<signature.size();j++)if(signature[j]>=0&&code[i+j]!=signature[j]){match=false;break;}
        if(match){if(i+instruction+displacementOffset+4>code.size())return 0;int32_t displacement=0;memcpy(&displacement,code.data()+i+instruction+displacementOffset,4);uintptr_t candidate=start+i+instruction+length+displacement;if(result&&candidate!=result)return 0;result=candidate;}
    }
    return result;
}
static bool ScanGame(){
    auto base=reinterpret_cast<uintptr_t>(GetModuleHandleW(nullptr));IMAGE_DOS_HEADER dos{};IMAGE_NT_HEADERS64 nt{};
    if(!Read(base,dos)||dos.e_magic!=IMAGE_DOS_SIGNATURE||!Read(base+dos.e_lfanew,nt)||nt.Signature!=IMAGE_NT_SIGNATURE)return false;
    uintptr_t section=base+dos.e_lfanew+sizeof(DWORD)+sizeof(IMAGE_FILE_HEADER)+nt.FileHeader.SizeOfOptionalHeader;
    for(int s=0;s<nt.FileHeader.NumberOfSections;s++){
        IMAGE_SECTION_HEADER header{};if(!Read(section+s*sizeof(header),header))continue;
        if(memcmp(header.Name,".text",5)!=0)continue;
        if(header.Misc.VirtualSize>128*1024*1024)return false;
        std::vector<unsigned char> code(header.Misc.VirtualSize);SIZE_T got=0;auto start=base+header.VirtualAddress;
        if(!ReadProcessMemory(GetCurrentProcess(),reinterpret_cast<void*>(start),code.data(),code.size(),&got)||got!=code.size())return false;
        chrGlobal=FindGlobal(code,start,{0x48,0x8B,0x3D,-1,-1,-1,-1,0x40,0x32});
        areaGlobal=FindGlobal(code,start,{0x48,0x8B,0x1D,-1,-1,-1,-1,0x41,0x0F,0xB6,0xF8,0x48,0x85,0xDB,0x74,0x25});
        eventGlobal=FindGlobal(code,start,{0x84,0xC0,0x75,0x6E,0x48,0x8B,0x0D},4);
        menuGlobal=FindGlobal(code,start,{0x48,0x8B,0x05,-1,-1,-1,-1,0x48,0x8B,0x88,0x88,0x30});
        auto eventAddress=FindGlobal(code,start,{0xE8,-1,-1,-1,-1,0x84,0xC0,0x74,0x02,0x0B,0xF3},0,1,5);
        auto warpAddress=FindGlobal(code,start,{0xBA,0x10,0x27,0,0,0x41,0xB8,0x64,0xEB,0,0,0xE8,-1,-1,-1,-1},0x1A,1,5);
        getEvent=eventAddress>=start&&eventAddress<start+code.size()?reinterpret_cast<EventFn>(eventAddress):nullptr;
        warpToIdol=warpAddress>=start&&warpAddress<start+code.size()?reinterpret_cast<WarpFn>(warpAddress):nullptr;
        // Warp's request manager is reached by its call to SetRespawnEntityId.
        if(warpToIdol&&warpAddress-start+256<=code.size()){
            std::vector<unsigned char> body(code.begin()+(warpAddress-start),code.begin()+(warpAddress-start)+256);
            auto function=FindGlobal(body,warpAddress,{0x8D,0x8B,0xE8,0x03,0,0,0xE8,-1,-1,-1,-1,0x85,0xFF},6,1,5);
            int32_t delta=0;unsigned char prefix[3]{};
            if(function>=start&&function+7<start+code.size()&&Read(function,prefix)&&prefix[0]==0x48&&prefix[1]==0x8B&&prefix[2]==0x05&&Read(function+3,delta))warpGlobal=function+7+delta;
        }
        Log(std::string("Travel signatures: ")+(getEvent&&warpToIdol&&eventGlobal&&menuGlobal&&warpGlobal?"resolved":"unavailable"));
        if(chrGlobal && areaGlobal){memoryStatus="定位入口已找到";Log("Unique game signatures resolved");return true;}
    }
    memoryStatus="尚未找到定位入口；请进入游戏后重试";return false;
}
static int MapFromIndex(int index){
    const char* id=nullptr;
    switch(index){case 0:id="m10_00_00_00";break;case 1:id="m11_00_00_00";break;case 2:id="m11_01_00_00";break;case 3:id="m11_02_00_00";break;case 6:id="m13_00_00_00";break;case 7:id="m15_00_00_00";break;case 9:id="m17_00_00_00";break;case 11:id="m20_00_00_00";break;case 12:id="m25_00_00_00";break;}
    if(id)for(size_t i=0;i<maps.size();i++)if(maps[i].id==id)return static_cast<int>(i);
    return -1;
}
static void UpdatePlayer(){
    player={};
    if(previewMode){
        if(maps.empty())return;int index=0;for(size_t i=0;i<maps.size();i++)if(maps[i].id=="m11_00_00_00")index=static_cast<int>(i);
        if(maps[index].idols.empty())return;auto& idol=maps[index].idols[std::min<size_t>(1,maps[index].idols.size()-1)];
        player={true,index,idol.x+8,idol.y,idol.z+3,0.5f};return;
    }
    if(!chrGlobal||!areaGlobal)return;
    uintptr_t world=Pointer(chrGlobal),chr=Pointer(world+0x88),modules=Pointer(chr+0x1FF8),physics=Pointer(modules+0x68),area=Pointer(areaGlobal);
    int index=-1;float values[3]={};
    if(!world||!chr||!modules||!physics||!area||!Read(area+0x28,index)||!Read(physics+0x80,values)||!Read(physics+0x74,player.angle))return;
    player.map=MapFromIndex(index);player.x=values[0];player.y=values[1];player.z=values[2];
    player.valid=player.map>=0&&std::isfinite(player.x)&&std::isfinite(player.y)&&std::isfinite(player.z)&&std::isfinite(player.angle)&&std::abs(player.x)<100000&&std::abs(player.y)<100000&&std::abs(player.z)<100000;
    if(player.valid){
        auto& offsets=config["playerOffsets"];
        if(offsets.contains(maps[player.map].id)){auto& offset=offsets[maps[player.map].id];player.x+=JsonFloat(offset,"x",0);player.y+=JsonFloat(offset,"y",0);player.z+=JsonFloat(offset,"z",0);}
    }
}
static ID3D11ShaderResourceView* LoadTexture(const fs::path& path){
    IWICImagingFactory* factory=nullptr;IWICBitmapDecoder* decoder=nullptr;IWICBitmapFrameDecode* frame=nullptr;IWICFormatConverter* converter=nullptr;
    ID3D11Texture2D* texture=nullptr;ID3D11ShaderResourceView* view=nullptr;UINT width=0,height=0;
    HRESULT result=CoCreateInstance(CLSID_WICImagingFactory,nullptr,CLSCTX_INPROC_SERVER,IID_IWICImagingFactory,reinterpret_cast<void**>(&factory));
    if(SUCCEEDED(result))result=factory->CreateDecoderFromFilename(path.c_str(),nullptr,GENERIC_READ,WICDecodeMetadataCacheOnLoad,&decoder);
    if(SUCCEEDED(result))result=decoder->GetFrame(0,&frame);
    if(SUCCEEDED(result))result=factory->CreateFormatConverter(&converter);
    if(SUCCEEDED(result))result=converter->Initialize(frame,GUID_WICPixelFormat32bppRGBA,WICBitmapDitherTypeNone,nullptr,0,WICBitmapPaletteTypeCustom);
    if(SUCCEEDED(result))result=converter->GetSize(&width,&height);
    if(SUCCEEDED(result)&&width>0&&height>0&&width<=8192&&height<=8192){
        std::vector<unsigned char> pixels(static_cast<size_t>(width)*height*4);
        result=converter->CopyPixels(nullptr,width*4,static_cast<UINT>(pixels.size()),pixels.data());
        if(SUCCEEDED(result)){
            D3D11_TEXTURE2D_DESC description{};description.Width=width;description.Height=height;description.MipLevels=1;description.ArraySize=1;description.Format=DXGI_FORMAT_R8G8B8A8_UNORM;description.SampleDesc.Count=1;description.Usage=D3D11_USAGE_IMMUTABLE;description.BindFlags=D3D11_BIND_SHADER_RESOURCE;
            D3D11_SUBRESOURCE_DATA input{pixels.data(),width*4,0};result=device->CreateTexture2D(&description,&input,&texture);
            if(SUCCEEDED(result))result=device->CreateShaderResourceView(texture,nullptr,&view);
        }
    }
    if(texture)texture->Release();if(converter)converter->Release();if(frame)frame->Release();if(decoder)decoder->Release();if(factory)factory->Release();
    if(FAILED(result)){Log("Texture load failed: "+path.filename().string());return nullptr;}return view;
}
static float SurfaceHeight(const Map& map,Layer& layer,float x,float z){
    if(layer.heights.empty()){std::ifstream file(layer.heightFile,std::ios::binary);if(!file)return NAN;layer.heights.resize(static_cast<size_t>(map.width)*map.height);file.read(reinterpret_cast<char*>(layer.heights.data()),layer.heights.size()*sizeof(float));if(!file){layer.heights.clear();return NAN;}}
    int px=static_cast<int>((x-map.minX)/(map.maxX-map.minX)*(map.width-1));int py=static_cast<int>((map.maxZ-z)/(map.maxZ-map.minZ)*(map.height-1));
    if(px<0||py<0||px>=map.width||py>=map.height)return NAN;return layer.heights[static_cast<size_t>(py)*map.width+px];
}
static void ChooseLayer(Map& map){
    if(!automaticLayer||!player.valid||map.layers.size()<2)return;
    static int candidate=0;static double since=0;
    int selected=0;float h=SurfaceHeight(map,map.layers[0],player.x,player.z);
    if(std::isfinite(h)&&h-player.y>5){float best=INFINITY;for(size_t i=1;i<map.layers.size();i++){
        float cut=map.layers[i].ceiling;if(cut>=player.y+1.5f&&cut<best){best=cut;selected=static_cast<int>(i);}}}
    if(candidate!=selected){candidate=selected;since=ImGui::GetTime();}
    if(ImGui::GetTime()-since>.65)layerIndex=selected;
}
static bool GameLoaded(){unsigned char loaded=0;auto menu=Pointer(menuGlobal);return menu&&Read(menu+0x20,loaded)&&loaded==1;}
static bool PlayerReadyForTravel(){
    if(previewMode)return player.valid;
    if(!player.valid||!GameLoaded()||!getEvent||!warpToIdol||!Pointer(warpGlobal))return false;
    auto world=Pointer(chrGlobal),chr=Pointer(world+0x88),modules=Pointer(chr+0x1FF8),data=Pointer(modules+0x18);int hp=0;
    return data&&Read(data+0x130,hp)&&hp>0;
}
static IdolState QueryIdol(const Idol& idol){
    bool metadata=idol.entity>0&&idol.unlockFlag>0;
    if(previewMode)return ResolveIdolState(metadata,true,idol.unlockFlag%10!=2,idol.disabledFlag%10==3);
    auto manager=Pointer(eventGlobal);unsigned char initialized=0;
    bool readable=getEvent&&manager&&Read(manager+0x228,initialized)&&initialized!=0&&GameLoaded();
    if(!metadata||!readable)return IdolState::Unknown;
    // The third argument selects the debug flag namespace. Always use the save's normal namespace.
    return ResolveIdolState(true,true,getEvent(manager,idol.unlockFlag,false),idol.disabledFlag>0&&getEvent(manager,idol.disabledFlag,false));
}
static void RefreshIdols(bool force=false){
    static ULONGLONG refreshed=0;auto now=GetTickCount64();if(!force&&now-refreshed<1000)return;refreshed=now;
    auto manager=Pointer(eventGlobal);unsigned char initialized=0;bool canRead=getEvent&&manager&&Read(manager+0x228,initialized)&&initialized!=0&&GameLoaded();
    for(auto& map:maps){for(auto& idol:map.idols)idol.state=QueryIdol(idol);
        for(auto& boss:map.bosses)boss.state=previewMode?boss.entity%2:canRead&&boss.deathFlag>0?(getEvent(manager,boss.deathFlag,false)?1:0):-1;
    }
}
static const char* IdolStateText(IdolState state){switch(state){case IdolState::Available:return "已解锁 · 可传送";case IdolState::Locked:return "未解锁";case IdolState::Unavailable:return "当前剧情不可用";default:return "状态未确认 · 暂不可传送";}}
static void CenterPlayerView(){
    fullZoom=10;selectedIdol=-1;
    if(player.valid){displayedMap=player.map;layerIndex=0;auto& map=maps[displayedMap];panX=player.x-(map.minX+map.maxX)/2;panY=player.z-(map.minZ+map.maxZ)/2;}
    else panX=panY=0;
}
static int HitIdol(const Map& map,ImVec2 mouse,ImVec2 position,ImVec2 size,float centerX,float centerZ,float pixelsPerUnit,float radius){
    if(mouse.x<position.x||mouse.y<position.y||mouse.x>position.x+size.x||mouse.y>position.y+size.y)return -1;
    int hit=-1;float best=radius*radius;
    for(size_t i=0;i<map.idols.size();i++){auto& idol=map.idols[i];float dx=position.x+size.x*.5f+(idol.x-centerX)*pixelsPerUnit-mouse.x;float dy=position.y+size.y*.5f-(idol.z-centerZ)*pixelsPerUnit-mouse.y;float distance=dx*dx+dy*dy;if(distance<=best){best=distance;hit=static_cast<int>(i);}}
    return hit;
}
static bool RequestTravel(int mapIndex,int idolIndex){
    if(mapIndex<0||mapIndex>=static_cast<int>(maps.size())||idolIndex<0||idolIndex>=static_cast<int>(maps[mapIndex].idols.size()))return false;
    auto& idol=maps[mapIndex].idols[idolIndex];idol.state=QueryIdol(idol);
    if(!CanTravel(idol.state,PlayerReadyForTravel(),travelBusy,allowLockedTravel)){travelMessage="此鬼佛当前不可传送。";return false;}
    pendingTravelMap=mapIndex;pendingTravelIdol=idolIndex;travelMessage="正在传送到 "+idol.name;SetMapOpen(false);travelBusy=true;return true;
}
static void DispatchTravel(){
    if(pendingTravelMap<0)return;auto& idol=maps[pendingTravelMap].idols[pendingTravelIdol];pendingTravelMap=pendingTravelIdol=-1;
    // Recheck the save after leaving the UI and before issuing the game's loading request.
    idol.state=QueryIdol(idol);
    if(!CanTravel(idol.state,PlayerReadyForTravel(),false,allowLockedTravel)){travelBusy=false;travelMessage="传送已取消：玩家或鬼佛状态已变化。";return;}
    lastTravelEntity=idol.entity;travelStarted=GetTickCount64();travelSawLoading=false;
    if(previewMode){travelBusy=false;travelMessage="模拟传送测试通过";return;}
    Log("Native idol warp requested: "+std::to_string(idol.entity));warpRequests++;
    // The game's function derives the map and respawn entity from this idol ID, then requests a load.
    warpToIdol(nullptr,idol.entity,0);
}
static void UpdateTravel(){
    if(!travelBusy||pendingTravelMap>=0)return;
    bool loaded=GameLoaded();if(!loaded)travelSawLoading=true;
    if(loaded&&travelSawLoading&&player.valid){travelBusy=false;travelMessage="传送加载完成";Log("Native idol warp load completed");RefreshIdols(true);}
    else if(GetTickCount64()-travelStarted>(travelSawLoading?60000:15000)){travelBusy=false;travelMessage="尚未确认传送完成，请检查游戏状态。";Log("Native idol warp completion timed out");}
}
static void ControllerRegion(int direction){
    if(maps.empty())return;displayedMap=(displayedMap+direction+static_cast<int>(maps.size()))%static_cast<int>(maps.size());
    layerIndex=0;panX=panY=0;fullZoom=1;selectedIdol=-1;travelMessage.clear();controllerActions++;
}
static void ControllerSelectIdol(int direction){
    if(displayedMap<0)return;auto& map=maps[displayedMap];int count=static_cast<int>(map.idols.size());
    if(!count)return;int start=selectedIdol<0?(direction>0?-1:0):selectedIdol;
    for(int step=1;step<=count;step++){int index=(start+direction*step+count*2)%count;auto& idol=map.idols[index];if(!CanTravel(idol.state,true,false,allowLockedTravel))continue;
        selectedIdol=index;panX=idol.x-(map.minX+map.maxX)/2;panY=idol.z-(map.minZ+map.maxZ)/2;travelMessage.clear();controllerActions++;return;
    }
    travelMessage="此区域没有可传送的鬼佛。";
}
static void HandleController(const XINPUT_GAMEPAD& pad,float delta){
    static_assert(ControllerMapChord==(XINPUT_GAMEPAD_LEFT_SHOULDER|XINPUT_GAMEPAD_DPAD_UP));
    bool toggle=false;WORD pressed=controllerButtons.Poll(pad.wButtons,toggle);
    if(toggle){SetMapOpen(!mapOpen);uiHidden=false;controllerActions++;if(mapOpen&&centerOnOpen.exchange(false))CenterPlayerView();}
    if(!mapOpen||displayedMap<0||travelBusy)return;
    if(pressed&XINPUT_GAMEPAD_B){SetMapOpen(false);controllerActions++;return;}
    if(pressed&XINPUT_GAMEPAD_LEFT_THUMB){SetAllowLockedTravel(!allowLockedTravel);controllerActions++;}
    if(pressed&XINPUT_GAMEPAD_LEFT_SHOULDER)ControllerRegion(-1);
    if(pressed&XINPUT_GAMEPAD_RIGHT_SHOULDER)ControllerRegion(1);
    if(pressed&XINPUT_GAMEPAD_X){CenterPlayerView();controllerActions++;}
    if(pressed&XINPUT_GAMEPAD_Y){panX=panY=0;fullZoom=1;controllerActions++;}
    if(pressed&XINPUT_GAMEPAD_DPAD_LEFT)ControllerSelectIdol(-1);
    if(pressed&XINPUT_GAMEPAD_DPAD_RIGHT)ControllerSelectIdol(1);
    if(pressed&XINPUT_GAMEPAD_DPAD_UP){ChangeMinimapZoom(.8f);controllerActions++;}
    if(pressed&XINPUT_GAMEPAD_DPAD_DOWN){ChangeMinimapZoom(1.25f);controllerActions++;}
    if(pressed&XINPUT_GAMEPAD_RIGHT_THUMB){auto& map=maps[displayedMap];layerIndex=(layerIndex+1)%static_cast<int>(map.layers.size());automaticLayer=false;controllerActions++;}
    if(pressed&XINPUT_GAMEPAD_A){RequestTravel(displayedMap,selectedIdol);controllerActions++;if(!mapOpen)return;}
    auto& map=maps[displayedMap];float speed=std::max(map.maxX-map.minX,map.maxZ-map.minZ)/fullZoom*.7f;delta=std::clamp(delta,0.0f,.1f);
    panX+=ControllerAxis(pad.sThumbLX)*speed*delta;panY+=ControllerAxis(pad.sThumbLY)*speed*delta;
    float zoom=ControllerTrigger(pad.bRightTrigger)-ControllerTrigger(pad.bLeftTrigger);
    fullZoom=std::clamp(fullZoom*std::pow(2.0f,zoom*delta*1.7f),.5f,12.0f);
}
static void PollController(float delta){
    if(previewMode||!config.value("controllerEnabled",true)||!originalXInput||GetForegroundWindow()!=gameWindow)return;
    static ULONGLONG nextPoll=0;if(connectedController<0&&GetTickCount64()<nextPoll)return;
    XINPUT_STATE state{};int found=-1;{InputBypassScope allow;for(int i=0;i<4;i++)if(originalXInput(i,&state)==ERROR_SUCCESS){found=i;break;}}
    connectedController=found;
    if(found<0){controllerButtons={};nextPoll=GetTickCount64()+500;return;}
    HandleController(state.Gamepad,delta);
}
static ImU32 BossColor(int state){return state==1?IM_COL32(91,216,119,255):IM_COL32(239,84,79,255);}
static void DrawBull(ImDrawList* draw,ImVec2 p,float scale,int state){
    auto color=BossColor(state);auto point=[&](float x,float y){return ImVec2(p.x+x*scale,p.y+y*scale);};
    draw->AddCircleFilled(p,13*scale,IM_COL32(12,17,18,230));
    ImVec2 head[]={point(-5,-4),point(5,-4),point(4,4),point(0,8),point(-4,4)};draw->AddConvexPolyFilled(head,5,color);
    draw->AddBezierCubic(point(-4,-2),point(-11,0),point(-13,-5),point(-10,-9),color,3*scale);
    draw->AddBezierCubic(point(4,-2),point(11,0),point(13,-5),point(10,-9),color,3*scale);
    draw->AddTriangleFilled(point(-4,-2),point(-9,-1),point(-5,2),color);draw->AddTriangleFilled(point(4,-2),point(9,-1),point(5,2),color);
    draw->AddCircleFilled(point(-2,0),1.1f*scale,IM_COL32(12,17,18,255));draw->AddCircleFilled(point(2,0),1.1f*scale,IM_COL32(12,17,18,255));
    draw->AddLine(point(-1.5f,4.5f),point(1.5f,4.5f),IM_COL32(12,17,18,255),1.2f*scale);
}
static void DrawMap(Map& map,int index,ImVec2 position,ImVec2 size,float centerX,float centerZ,float pixelsPerUnit,bool labels,bool showPlayer){
    auto& layer=map.layers[index];if(!layer.texture)layer.texture=LoadTexture(layer.image);
    auto* draw=ImGui::GetWindowDrawList();draw->AddRectFilled(position,ImVec2(position.x+size.x,position.y+size.y),IM_COL32(24,29,29,255));
    draw->PushClipRect(position,ImVec2(position.x+size.x,position.y+size.y),true);
    auto screen=[&](float x,float z){return ImVec2(position.x+size.x*.5f+(x-centerX)*pixelsPerUnit,position.y+size.y*.5f-(z-centerZ)*pixelsPerUnit);};
    if(layer.texture)draw->AddImage(reinterpret_cast<ImTextureID>(layer.texture),screen(map.minX,map.maxZ),screen(map.maxX,map.minZ));
    float iconScale=std::clamp(ImGui::GetIO().DisplaySize.y/1080.0f,.75f,2.0f)*(labels?1.0f:1.5f);
    for(size_t idolIndex=0;idolIndex<map.idols.size();idolIndex++){auto& idol=map.idols[idolIndex];
        auto p=screen(idol.x,idol.z);if(p.x<position.x-10||p.y<position.y-10||p.x>position.x+size.x+10||p.y>position.y+size.y+10)continue;
        float difference=showPlayer?idol.y-player.y:0;auto color=CanTravel(idol.state,true,false,allowLockedTravel)?IM_COL32(82,229,226,255):IM_COL32(161,165,165,255);
        if(labels&&static_cast<int>(idolIndex)==selectedIdol)draw->AddCircle(p,13*iconScale,IM_COL32(255,217,119,255),20,2);
        draw->AddCircleFilled(p,8*iconScale,IM_COL32(5,20,24,230));draw->AddCircle(p,6*iconScale,color,16,2*iconScale);
        draw->AddLine(ImVec2(p.x-3*iconScale,p.y),ImVec2(p.x+3*iconScale,p.y),color,1.5f*iconScale);draw->AddLine(ImVec2(p.x,p.y-3*iconScale),ImVec2(p.x,p.y+3*iconScale),color,1.5f*iconScale);
        if(labels){auto at=ImVec2(p.x+15*iconScale,p.y-8);draw->AddText(ImVec2(at.x+1,at.y+1),IM_COL32(0,0,0,255),idol.name.c_str());draw->AddText(at,IM_COL32(223,248,240,255),idol.name.c_str());}
        if(std::abs(difference)>7)draw->AddText(ImVec2(p.x-4,p.y+10*iconScale),color,difference>0?"↑":"↓");
    }
    int hoveredBoss=-1;float hoverDistance=INFINITY;float bossScale=std::clamp(ImGui::GetIO().DisplaySize.y/1080.0f,.75f,2.0f)*(labels?1.0f:.9f);
    for(size_t i=0;i<map.bosses.size();i++){auto& boss=map.bosses[i];auto origin=screen(boss.x,boss.z),p=origin;
        int groupSize=0,rank=0;for(size_t j=0;j<map.bosses.size();j++){auto& other=map.bosses[j];if(std::hypot(other.x-boss.x,other.z-boss.z)<4&&std::abs(other.y-boss.y)<8){if(j<i)rank++;groupSize++;}}
        if(groupSize>1){float angle=6.283185307f*rank/groupSize;p.x+=std::cos(angle)*21*bossScale;p.y+=std::sin(angle)*21*bossScale;draw->AddLine(origin,p,BossColor(boss.state),1);}
        if(p.x<position.x-15||p.y<position.y-15||p.x>position.x+size.x+15||p.y>position.y+size.y+15)continue;
        DrawBull(draw,p,bossScale,boss.state);
        if(labels){if(fullZoom>=2.5f){auto at=ImVec2(p.x+17*bossScale,p.y-8);draw->AddText(ImVec2(at.x+1,at.y+1),IM_COL32(0,0,0,255),boss.name.c_str());draw->AddText(at,BossColor(boss.state),boss.name.c_str());}
            auto mouse=ImGui::GetIO().MousePos;float distance=std::hypot(mouse.x-p.x,mouse.y-p.y);if(distance<16*bossScale&&distance<hoverDistance){hoverDistance=distance;hoveredBoss=static_cast<int>(i);}
        }
        if(showPlayer&&std::abs(boss.y-player.y)>7)draw->AddText(ImVec2(p.x-4,p.y+13*bossScale),BossColor(boss.state),boss.y>player.y?"↑":"↓");
    }
    if(showPlayer){
        auto p=screen(player.x,player.z);float corrected=player.angle+3.14159265358979323846f;float dx=std::sin(corrected),dy=-std::cos(corrected);float radius=11;
        draw->AddCircleFilled(p,13,IM_COL32(10,15,16,170));
        draw->AddTriangleFilled(ImVec2(p.x+dx*radius,p.y+dy*radius),ImVec2(p.x-dx*7-dy*7,p.y-dy*7+dx*7),ImVec2(p.x-dx*7+dy*7,p.y-dy*7-dx*7),IM_COL32(255,217,119,255));
    }
    draw->PopClipRect();draw->AddRect(position,ImVec2(position.x+size.x,position.y+size.y),IM_COL32(189,179,137,180),0.0f,1.0f,ImDrawFlags_None);
    draw->AddText(ImVec2(position.x+size.x-24,position.y+9),IM_COL32(241,224,175,255),"N");
    if(hoveredBoss>=0&&ImGui::IsMouseHoveringRect(position,ImVec2(position.x+size.x,position.y+size.y))){auto& boss=map.bosses[hoveredBoss];ImGui::BeginTooltip();ImGui::TextUnformatted(boss.name.c_str());ImGui::TextUnformatted(boss.state==1?"当前周目已击杀":boss.state==0?"当前周目未击杀":"正在读取击杀状态");ImGui::EndTooltip();}
}
static void RenderUI(){
    if(maps.empty()){ImGui::Begin("地图加载失败");ImGui::TextUnformatted("没有找到地图数据。请保持 maps 文件夹与 AtlasMod.dll 位于同一目录。");ImGui::End();return;}
    auto& io=ImGui::GetIO();float scale=std::clamp(io.DisplaySize.y/1080.0f,.75f,2.0f);
    if(previewLarge.load()>=0){static int previousPreview=-2;int wanted=previewLarge.load();if(wanted!=previousPreview){SetMapOpen(false);SetMapOpen(wanted!=0);previousPreview=wanted;
        if(wanted==2&&player.valid){displayedMap=player.map;layerIndex=0;fullZoom=1;panX=panY=0;centerOnOpen=false;}}
    }
    if(player.valid&&(displayedMap<0||(!mapOpen&&displayedMap!=player.map))){displayedMap=player.map;layerIndex=0;fullZoom=1;panX=panY=0;}
    if(displayedMap<0)displayedMap=0;
    if(mapOpen&&centerOnOpen.exchange(false))CenterPlayerView();
    auto& map=maps[displayedMap];layerIndex=std::clamp(layerIndex,0,static_cast<int>(map.layers.size()-1));
    if(player.valid&&player.map==displayedMap)ChooseLayer(map);
    float centerX=player.valid&&player.map==displayedMap?player.x:(map.minX+map.maxX)/2;
    float centerZ=player.valid&&player.map==displayedMap?player.z:(map.minZ+map.maxZ)/2;
    if(!mapOpen){
        float side=std::clamp(JsonFloat(config,"minimapSize",320),180.0f,600.0f)*scale;
        ImGui::SetNextWindowPos(ImVec2(io.DisplaySize.x-side-24*scale,24*scale));ImGui::SetNextWindowSize(ImVec2(side,side+96*scale));
        ImGui::SetNextWindowBgAlpha(std::clamp(JsonFloat(config,"opacity",.93f),.2f,1.0f));
        ImGui::Begin("##minimap",nullptr,ImGuiWindowFlags_NoDecoration|ImGuiWindowFlags_NoMove|ImGuiWindowFlags_NoInputs|ImGuiWindowFlags_NoSavedSettings);
        ImGui::Text("%s%s",map.name.c_str(),previewMode?" · 模拟站位":!player.valid?" · 等待进入游戏":"");
        float inner=side-20;auto pos=ImGui::GetCursorScreenPos();DrawMap(map,layerIndex,pos,ImVec2(inner,inner),centerX,centerZ,inner/(2*minimapRadius.load()),false,player.valid&&player.map==displayedMap);
        ImGui::Dummy(ImVec2(inner,inner));
        ImGui::TextColored(ImVec4(.75f,.75f,.68f,1),config.value("controllerEnabled",true)?"M / LB+十字键↑：大地图":"M：大地图");
        ImGui::Text("F6/F7 缩放 · F9 隐藏 · %.0f%%",65.0f/minimapRadius.load()*100);
        if(travelBusy)ImGui::TextUnformatted("正在传送...");
        ImGui::End();return;
    }
    ImGui::SetNextWindowPos(ImVec2(io.DisplaySize.x*.05f,io.DisplaySize.y*.05f));ImGui::SetNextWindowSize(ImVec2(io.DisplaySize.x*.90f,io.DisplaySize.y*.90f));
    ImGui::SetNextWindowBgAlpha(.98f);ImGui::Begin("只狼 · 地形地图",nullptr,ImGuiWindowFlags_NoResize|ImGuiWindowFlags_NoMove|ImGuiWindowFlags_NoCollapse|ImGuiWindowFlags_NoSavedSettings);
    ImGui::SetNextItemWidth(220*scale);
    if(ImGui::BeginCombo("区域",map.name.c_str())){
        for(size_t i=0;i<maps.size();i++)if(ImGui::Selectable(maps[i].name.c_str(),static_cast<int>(i)==displayedMap)){displayedMap=static_cast<int>(i);layerIndex=0;fullZoom=1;panX=panY=0;selectedIdol=-1;}
        ImGui::EndCombo();
    }
    ImGui::SameLine();if(ImGui::Button("定位玩家")&&player.valid)CenterPlayerView();
    ImGui::SameLine();if(ImGui::Button("区域全览")){panX=panY=0;fullZoom=1;}
    ImGui::SameLine();if(ImGui::Button("关闭地图"))SetMapOpen(false);
    auto& current=maps[displayedMap];layerIndex=std::clamp(layerIndex,0,static_cast<int>(current.layers.size()-1));
    if(current.layers.size()>1){
        ImGui::SetNextItemWidth(240*scale);if(ImGui::BeginCombo("图层",current.layers[layerIndex].name.c_str())){for(size_t i=0;i<current.layers.size();i++)if(ImGui::Selectable(current.layers[i].name.c_str(),static_cast<int>(i)==layerIndex)){layerIndex=static_cast<int>(i);automaticLayer=false;}ImGui::EndCombo();}
        ImGui::SameLine();ImGui::Checkbox("自动高度切层（试验）",&automaticLayer);
    }
    ImGui::TextColored(ImVec4(.70f,.77f,.76f,1),"滚轮缩放 · 左键拖动 · 点击鬼佛选择 · 青色：可传送 / 灰色：不可传送 · M / Esc 关闭");
    ImGui::TextColored(ImVec4(.70f,.77f,.76f,1),"牛头：红色未击杀 / 绿色已击杀 · ↑↓ 表示与玩家的高度差");
    ImGui::TextColored(ImVec4(1,.77f,.42f,1),"查看地图时游戏继续运行。请在安全位置，或先打开游戏暂停菜单。");
    if(config.value("controllerEnabled",true)){
        ImGui::TextColored(ImVec4(.70f,.77f,.76f,1),"Xbox：LB+十字↑ 开关 / B 关闭 · 左摇杆平移 · LT/RT 缩放 · LB/RB 切区域 · 十字左右选鬼佛 · A 传送");
        ImGui::TextColored(ImVec4(.70f,.77f,.76f,1),"X 定位玩家 · Y 区域全览 · 十字上下缩放小地图 · R3 切图层 · L3 切换未解锁传送");
    }
    bool allowLocked=allowLockedTravel;ImGui::BeginDisabled(travelBusy);if(ImGui::Checkbox("允许传送到未解锁的鬼佛",&allowLocked))SetAllowLockedTravel(allowLocked);ImGui::EndDisabled();
    if(allowLocked)ImGui::SameLine(),ImGui::TextColored(ImVec4(1,.77f,.42f,1),"已开启 · 当前剧情不可用的鬼佛仍不可传送");
    ImGui::SetNextItemWidth(340*scale);
    if(ImGui::BeginCombo("目的地",selectedIdol>=0&&selectedIdol<static_cast<int>(current.idols.size())?current.idols[selectedIdol].name.c_str():"点击鬼佛，或在这里选择")){
        for(size_t i=0;i<current.idols.size();i++){auto& idol=current.idols[i];ImGui::PushID(static_cast<int>(i));std::string label=idol.name+" · "+IdolStateText(idol.state);if(ImGui::Selectable(label.c_str(),selectedIdol==static_cast<int>(i)))selectedIdol=static_cast<int>(i);ImGui::PopID();}ImGui::EndCombo();
    }
    ImGui::SameLine();bool selected=selectedIdol>=0&&selectedIdol<static_cast<int>(current.idols.size());bool allowed=selected&&CanTravel(current.idols[selectedIdol].state,PlayerReadyForTravel(),travelBusy,allowLockedTravel);
    ImGui::BeginDisabled(!allowed);if(ImGui::Button(previewMode?"模拟传送":"传送到此鬼佛"))RequestTravel(displayedMap,selectedIdol);ImGui::EndDisabled();
    if(selected){ImGui::SameLine();ImGui::TextUnformatted(IdolStateText(current.idols[selectedIdol].state));}
    if(!travelMessage.empty())ImGui::TextUnformatted(travelMessage.c_str());
    auto pos=ImGui::GetCursorScreenPos();auto available=ImGui::GetContentRegionAvail();available.y-=32*scale;available.x=std::max(available.x,100.0f);available.y=std::max(available.y,100.0f);
    float fit=std::min(available.x/(current.maxX-current.minX),available.y/(current.maxZ-current.minZ));float pixelScale=fit*fullZoom;
    float cx=(current.minX+current.maxX)/2+panX,cz=(current.minZ+current.maxZ)/2+panY;
    ImGui::InvisibleButton("map-canvas",available,ImGuiButtonFlags_MouseButtonLeft);
    if(ImGui::IsItemHovered()){
        if(io.MouseWheel!=0){float next=std::clamp(fullZoom*std::pow(1.2f,io.MouseWheel),.5f,12.0f);float ox=(io.MousePos.x-pos.x-available.x*.5f)/pixelScale,oz=-(io.MousePos.y-pos.y-available.y*.5f)/pixelScale;panX+=ox*(1-fullZoom/next);panY+=oz*(1-fullZoom/next);fullZoom=next;}
    }
    if(ImGui::IsItemActive()&&ImGui::IsMouseDragging(ImGuiMouseButton_Left)){panX-=io.MouseDelta.x/pixelScale;panY+=io.MouseDelta.y/pixelScale;}
    if(ImGui::IsItemHovered()&&ImGui::IsMouseReleased(ImGuiMouseButton_Left)&&io.MouseDragMaxDistanceSqr[ImGuiMouseButton_Left]<io.MouseDragThreshold*io.MouseDragThreshold){int hit=HitIdol(current,io.MousePos,pos,available,cx,cz,pixelScale,16*scale);if(hit>=0){selectedIdol=hit;travelMessage.clear();}}
    DrawMap(current,layerIndex,pos,available,cx,cz,pixelScale,true,player.valid&&player.map==displayedMap);
    ImGui::Text("%s  |  %.1fx",previewMode?"模拟站位":player.valid?"实时定位":"未读取到玩家",fullZoom);
    ImGui::End();
}
extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND,UINT,WPARAM,LPARAM);
static LRESULT CALLBACK WndProc(HWND window,UINT message,WPARAM w,LPARAM l){
    if(message==WM_KILLFOCUS&&mapOpen)SetMapOpen(false);
    if(message==WM_KEYDOWN&&!(l&(1LL<<30))){
        int mapKey=config.value("mapKey",77),hideKey=config.value("hideKey",120);
        if(static_cast<int>(w)==mapKey){SetMapOpen(!mapOpen);uiHidden=false;return 0;}
        if(static_cast<int>(w)==hideKey){uiHidden=!uiHidden;if(uiHidden)SetMapOpen(false);return 0;}
        if(static_cast<int>(w)==config.value("zoomOutKey",117)){ChangeMinimapZoom(1.25f);return 0;}
        if(static_cast<int>(w)==config.value("zoomInKey",118)){ChangeMinimapZoom(.8f);return 0;}
        if(w==VK_ESCAPE&&mapOpen){SetMapOpen(false);return 0;}
    }
    if(ready&&mapOpen){{InputBypassScope allow;ImGui_ImplWin32_WndProcHandler(window,message,w,l);}if(message>=WM_MOUSEFIRST&&message<=WM_MOUSELAST)return 0;if(message>=WM_KEYFIRST&&message<=WM_KEYLAST)return 0;if(message==WM_INPUT){DefWindowProcW(window,message,w,l);return 0;}}
    return CallWindowProcW(originalWndProc,window,message,w,l);
}
template<int Slot>static HRESULT STDMETHODCALLTYPE InputState(IDirectInputDevice8W* object,DWORD bytes,LPVOID data){auto result=originalStates[Slot](object,bytes,data);if(SUCCEEDED(result)&&SuppressInput()&&!inputBypass&&data){memset(data,0,bytes);blockedDeviceReads++;}return result;}
template<int Slot>static HRESULT STDMETHODCALLTYPE InputData(IDirectInputDevice8W* object,DWORD bytes,LPDIDEVICEOBJECTDATA data,LPDWORD count,DWORD flags){auto result=originalDatas[Slot](object,bytes,data,count,flags);if(SUCCEEDED(result)&&SuppressInput()&&!inputBypass&&count){*count=0;blockedDeviceReads++;}return result;}
static bool GameCaller(void* address){auto value=reinterpret_cast<uintptr_t>(address);return value>=gameImageBegin&&value<gameImageEnd;}
static SHORT WINAPI AsyncKey(int key){if(!inputBypass&&SuppressInput()&&GameCaller(__builtin_return_address(0))){blockedKeyPolls++;return 0;}return originalAsyncKey(key);}
static SHORT WINAPI KeyState(int key){if(!inputBypass&&SuppressInput()&&GameCaller(__builtin_return_address(0))){blockedKeyPolls++;return 0;}return originalKey(key);}
static BOOL WINAPI CursorGet(LPPOINT point){if(!inputBypass&&SuppressInput()&&GameCaller(__builtin_return_address(0))&&point){*point=frozenCursor;blockedCursorCalls++;return TRUE;}return originalCursorGet(point);}
static BOOL WINAPI CursorSet(int x,int y){if(!inputBypass&&SuppressInput()&&GameCaller(__builtin_return_address(0))){blockedCursorCalls++;return TRUE;}return originalCursorSet(x,y);}
static BOOL WINAPI CursorClip(const RECT* rectangle){if(!inputBypass&&mapOpen&&GameCaller(__builtin_return_address(0))){blockedCursorCalls++;return TRUE;}return originalCursorClip(rectangle);}
static void HookInputDevice(void** table){
    static StateFn stateHooks[]={InputState<0>,InputState<1>,InputState<2>,InputState<3>,InputState<4>,InputState<5>,InputState<6>,InputState<7>};
    static DataFn dataHooks[]={InputData<0>,InputData<1>,InputData<2>,InputData<3>,InputData<4>,InputData<5>,InputData<6>,InputData<7>};
    bool stateExists=false,dataExists=false;for(int i=0;i<stateCount;i++)stateExists|=stateTargets[i]==table[9];for(int i=0;i<dataCount;i++)dataExists|=dataTargets[i]==table[10];
    if(!stateExists&&stateCount<8&&MH_CreateHook(table[9],reinterpret_cast<void*>(stateHooks[stateCount]),reinterpret_cast<void**>(&originalStates[stateCount]))==MH_OK){stateTargets[stateCount++]=table[9];}
    if(!dataExists&&dataCount<8&&MH_CreateHook(table[10],reinterpret_cast<void*>(dataHooks[dataCount]),reinterpret_cast<void**>(&originalDatas[dataCount]))==MH_OK){dataTargets[dataCount++]=table[10];}
}
template<int Slot>static DWORD WINAPI ControllerState(DWORD user,XINPUT_STATE* state){
    DWORD result;{InputBypassScope allow;result=xinputOriginals[Slot](user,state);}
    if(result==ERROR_SUCCESS&&!inputBypass&&state){
        if(gameWindow&&GetForegroundWindow()==gameWindow&&config.value("controllerEnabled",true)&&user<4){bool latched=gameChordLatched[user];state->Gamepad.wButtons=FilterMapChord(state->Gamepad.wButtons,latched);gameChordLatched[user]=latched;}
        if(SuppressInput())memset(&state->Gamepad,0,sizeof(state->Gamepad));
    }
    return result;
}
static bool CreateTarget(IDXGISwapChain* swap){ID3D11Texture2D* buffer=nullptr;auto hr=swap->GetBuffer(0,IID_ID3D11Texture2D,reinterpret_cast<void**>(&buffer));if(FAILED(hr))return false;D3D11_TEXTURE2D_DESC description{};buffer->GetDesc(&description);renderWidth=description.Width;renderHeight=description.Height;hr=device->CreateRenderTargetView(buffer,nullptr,&target);buffer->Release();return SUCCEEDED(hr);}
static bool InitializeRenderer(IDXGISwapChain* swap){
    CoInitializeEx(nullptr,COINIT_MULTITHREADED);
    if(FAILED(swap->GetDevice(IID_ID3D11Device,reinterpret_cast<void**>(&device))))return false;
    device->GetImmediateContext(&context);DXGI_SWAP_CHAIN_DESC description{};swap->GetDesc(&description);gameWindow=description.OutputWindow;
    if(!CreateTarget(swap))return false;
    ImGui::CreateContext();auto& io=ImGui::GetIO();io.IniFilename=nullptr;io.ConfigFlags|=ImGuiConfigFlags_NavEnableKeyboard|ImGuiConfigFlags_NoMouseCursorChange;
    ImFontConfig font;font.FontNo=0;auto* chinese=io.Fonts->AddFontFromFileTTF("C:\\Windows\\Fonts\\msyh.ttc",18,&font,io.Fonts->GetGlyphRangesChineseSimplifiedCommon());if(!chinese)io.Fonts->AddFontDefault();
    ImGui::StyleColorsDark();auto& style=ImGui::GetStyle();style.WindowRounding=7;style.FrameRounding=4;style.WindowPadding=ImVec2(10,10);style.Colors[ImGuiCol_WindowBg]=ImVec4(.045f,.062f,.063f,1);style.Colors[ImGuiCol_Button]=ImVec4(.16f,.23f,.23f,1);style.Colors[ImGuiCol_Header]=ImVec4(.22f,.33f,.30f,1);
    if(!ImGui_ImplWin32_Init(gameWindow)||!ImGui_ImplDX11_Init(device,context))return false;
    originalWndProc=reinterpret_cast<WNDPROC>(SetWindowLongPtrW(gameWindow,GWLP_WNDPROC,reinterpret_cast<LONG_PTR>(WndProc)));
    if(!originalWndProc)return false;
    primarySwap=swap;ready=true;Log("DX11 renderer initialized");return true;
}
static HRESULT STDMETHODCALLTYPE Present(IDXGISwapChain* swap,UINT interval,UINT flags){
    std::lock_guard<std::mutex> guard(renderLock);
    if(ready&&swap!=primarySwap)return originalPresent(swap,interval,flags);
    if(!ready&&!InitializeRenderer(swap))return originalPresent(swap,interval,flags);
    if(!target&&!CreateTarget(swap))return originalPresent(swap,interval,flags);
    static ULONGLONG scanAt=0;
    if(!previewMode&&(!chrGlobal||!areaGlobal)&&GetTickCount64()-scanAt>5000){scanAt=GetTickCount64();ScanGame();}
    UpdatePlayer();UpdateTravel();RefreshIdols();static ULONGLONG padFrame=0;auto now=GetTickCount64();float padDelta=padFrame?std::min((now-padFrame)/1000.0f,.1f):.016f;padFrame=now;PollController(padDelta);
    if(!uiHidden){
        ImGui_ImplDX11_NewFrame();{InputBypassScope allow;ImGui_ImplWin32_NewFrame();}ImGui::GetIO().DisplaySize=ImVec2(static_cast<float>(renderWidth),static_cast<float>(renderHeight));ImGui::GetStyle().FontScaleMain=std::clamp(renderHeight/1080.0f,.75f,2.0f);ImGui::NewFrame();ImGui::GetIO().MouseDrawCursor=mapOpen.load();RenderUI();ImGui::Render();
        ID3D11RenderTargetView* previous=nullptr;ID3D11DepthStencilView* depth=nullptr;context->OMGetRenderTargets(1,&previous,&depth);
        context->OMSetRenderTargets(1,&target,nullptr);ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());context->OMSetRenderTargets(1,&previous,depth);if(previous)previous->Release();if(depth)depth->Release();
    }
    DispatchTravel();
    static ULONGLONG reportAt=0;
    if(GetTickCount64()-reportAt>2000){reportAt=GetTickCount64();try{json idols=json::array();for(auto& map:maps)for(auto& idol:map.idols)idols.push_back({{"entity",idol.entity},{"name",idol.name},{"state",static_cast<int>(idol.state)}});json bosses=json::array();for(auto& map:maps)for(auto& boss:map.bosses)bosses.push_back({{"entity",boss.entity},{"name",boss.name},{"deathFlag",boss.deathFlag},{"state",boss.state}});float viewX=0,viewZ=0;if(displayedMap>=0){auto& map=maps[displayedMap];viewX=(map.minX+map.maxX)/2+panX;viewZ=(map.minZ+map.maxZ)/2+panY;}std::ofstream status(root/L"atlas-runtime.json");status<<json{{"version","0.5"},{"renderer",ready},{"preview",previewMode.load()},{"positionValid",player.valid},{"region",player.map>=0?maps[player.map].id:""},{"x",player.x},{"y",player.y},{"z",player.z},{"angle",player.angle},{"minimapRadius",minimapRadius.load()},{"fullZoom",fullZoom},{"viewCenterX",viewX},{"viewCenterZ",viewZ},{"travelAvailable",PlayerReadyForTravel()},{"allowLockedTravel",allowLockedTravel.load()},{"travelBusy",travelBusy.load()},{"warpRequests",warpRequests},{"lastTravelEntity",lastTravelEntity},{"travelMessage",travelMessage},{"idols",idols},{"bosses",bosses},{"connectedController",connectedController},{"controllerActions",controllerActions},{"blockedDeviceReads",blockedDeviceReads.load()},{"blockedKeyPolls",blockedKeyPolls.load()},{"blockedCursorCalls",blockedCursorCalls.load()},{"mapOpen",mapOpen.load()},{"memoryStatus",memoryStatus}}.dump(2);}catch(...){}}
    return originalPresent(swap,interval,flags);
}
static HRESULT STDMETHODCALLTYPE Resize(IDXGISwapChain* swap,UINT count,UINT width,UINT height,DXGI_FORMAT format,UINT flags){std::lock_guard<std::mutex> guard(renderLock);if(swap==primarySwap&&target){target->Release();target=nullptr;}return originalResize(swap,count,width,height,format,flags);}
static DWORD WINAPI Bootstrap(void*){
    wchar_t modulePath[32768]{};GetModuleFileNameW(selfModule,modulePath,32768);root=fs::path(modulePath).parent_path();logFile.open(root/L"atlas.log",std::ios::app);Log("Sekiro Atlas 0.5 starting");LoadData();
    gameImageBegin=reinterpret_cast<uintptr_t>(GetModuleHandleW(nullptr));IMAGE_DOS_HEADER dos{};IMAGE_NT_HEADERS64 nt{};if(Read(gameImageBegin,dos)&&Read(gameImageBegin+dos.e_lfanew,nt))gameImageEnd=gameImageBegin+nt.OptionalHeader.SizeOfImage;
    CoInitializeEx(nullptr,COINIT_MULTITHREADED);
    HWND window=CreateWindowExW(0,L"STATIC",L"Atlas hook bootstrap",WS_OVERLAPPED,0,0,16,16,nullptr,nullptr,selfModule,nullptr);
    DXGI_SWAP_CHAIN_DESC description{};description.BufferDesc.Width=16;description.BufferDesc.Height=16;description.BufferDesc.Format=DXGI_FORMAT_R8G8B8A8_UNORM;description.SampleDesc.Count=1;description.BufferUsage=DXGI_USAGE_RENDER_TARGET_OUTPUT;description.BufferCount=1;description.OutputWindow=window;description.Windowed=TRUE;description.SwapEffect=DXGI_SWAP_EFFECT_DISCARD;
    IDXGISwapChain* swap=nullptr;ID3D11Device* dummyDevice=nullptr;ID3D11DeviceContext* dummyContext=nullptr;
    HRESULT result=D3D11CreateDeviceAndSwapChain(nullptr,D3D_DRIVER_TYPE_HARDWARE,nullptr,0,nullptr,0,D3D11_SDK_VERSION,&description,&swap,&dummyDevice,nullptr,&dummyContext);
    if(FAILED(result))result=D3D11CreateDeviceAndSwapChain(nullptr,D3D_DRIVER_TYPE_WARP,nullptr,0,nullptr,0,D3D11_SDK_VERSION,&description,&swap,&dummyDevice,nullptr,&dummyContext);
    if(FAILED(result)){Log("Could not create DX11 bootstrap device");DestroyWindow(window);return 1;}
    auto table=*reinterpret_cast<void***>(swap);
    if(MH_Initialize()!=MH_OK||MH_CreateHook(table[8],reinterpret_cast<void*>(Present),reinterpret_cast<void**>(&originalPresent))!=MH_OK||MH_CreateHook(table[13],reinterpret_cast<void*>(Resize),reinterpret_cast<void**>(&originalResize))!=MH_OK){Log("DXGI hook creation failed");return 1;}
    IDirectInput8W* inputW=nullptr;
    if(SUCCEEDED(DirectInput8Create(GetModuleHandleW(nullptr),DIRECTINPUT_VERSION,IID_IDirectInput8W,reinterpret_cast<void**>(&inputW),nullptr))){for(const GUID* kind:{&GUID_SysKeyboard,&GUID_SysMouse}){IDirectInputDevice8W* inputDevice=nullptr;if(SUCCEEDED(inputW->CreateDevice(*kind,&inputDevice,nullptr))){HookInputDevice(*reinterpret_cast<void***>(inputDevice));inputDevice->Release();}}inputW->Release();}
    IDirectInput8A* inputA=nullptr;
    if(SUCCEEDED(DirectInput8Create(GetModuleHandleW(nullptr),DIRECTINPUT_VERSION,IID_IDirectInput8A,reinterpret_cast<void**>(&inputA),nullptr))){for(const GUID* kind:{&GUID_SysKeyboard,&GUID_SysMouse}){IDirectInputDevice8A* inputDevice=nullptr;if(SUCCEEDED(inputA->CreateDevice(*kind,&inputDevice,nullptr))){HookInputDevice(*reinterpret_cast<void***>(inputDevice));inputDevice->Release();}}inputA->Release();}
    auto user=GetModuleHandleW(L"user32.dll");
    MH_CreateHook(reinterpret_cast<void*>(GetProcAddress(user,"GetAsyncKeyState")),reinterpret_cast<void*>(AsyncKey),reinterpret_cast<void**>(&originalAsyncKey));
    MH_CreateHook(reinterpret_cast<void*>(GetProcAddress(user,"GetKeyState")),reinterpret_cast<void*>(KeyState),reinterpret_cast<void**>(&originalKey));
    MH_CreateHook(reinterpret_cast<void*>(GetProcAddress(user,"GetCursorPos")),reinterpret_cast<void*>(CursorGet),reinterpret_cast<void**>(&originalCursorGet));
    MH_CreateHook(reinterpret_cast<void*>(GetProcAddress(user,"SetCursorPos")),reinterpret_cast<void*>(CursorSet),reinterpret_cast<void**>(&originalCursorSet));
    MH_CreateHook(reinterpret_cast<void*>(GetProcAddress(user,"ClipCursor")),reinterpret_cast<void*>(CursorClip),reinterpret_cast<void**>(&originalCursorClip));
    Log("Input hooks: "+std::to_string(stateCount)+" distinct device state methods, "+std::to_string(dataCount)+" buffered methods");
    const wchar_t* libraries[]={L"xinput1_4.dll",L"xinput1_3.dll",L"xinput9_1_0.dll"};
    static XInputFn controllerHooks[]={ControllerState<0>,ControllerState<1>,ControllerState<2>};
    for(auto library:libraries){auto module=GetModuleHandleW(library);if(!module)module=LoadLibraryExW(library,nullptr,LOAD_LIBRARY_SEARCH_SYSTEM32);if(!module)continue;auto proc=reinterpret_cast<void*>(GetProcAddress(module,"XInputGetState"));bool exists=false;for(int i=0;i<xinputCount;i++)exists|=xinputTargets[i]==proc;
        if(proc&&!exists&&xinputCount<3&&MH_CreateHook(proc,reinterpret_cast<void*>(controllerHooks[xinputCount]),reinterpret_cast<void**>(&xinputOriginals[xinputCount]))==MH_OK){xinputTargets[xinputCount++]=proc;}}
    if(xinputCount)originalXInput=xinputOriginals[0];Log("Controller hooks: "+std::to_string(xinputCount));
    if(MH_EnableHook(MH_ALL_HOOKS)!=MH_OK){Log("Could not enable hooks");return 1;}
    dummyContext->Release();dummyDevice->Release();swap->Release();DestroyWindow(window);Log("Hooks enabled");return 0;
}
extern "C" __declspec(dllexport) void AtlasPreview(int large){previewMode=true;previewLarge=large;}
extern "C" __declspec(dllexport) int AtlasUIState(){return (mapOpen?1:0)|(uiHidden?2:0)|(ready?4:0);}
extern "C" __declspec(dllexport) float AtlasMinimapRadius(){return minimapRadius.load();}
extern "C" __declspec(dllexport) unsigned long long AtlasBlockedCursorCalls(){return blockedCursorCalls.load();}
extern "C" __declspec(dllexport) unsigned AtlasFeatureChecks(){
    if(!previewMode||!ready||!player.valid)return 0;
    unsigned checks=0;auto& map=maps[displayedMap];bool previousAllow=allowLockedTravel;SetAllowLockedTravel(false);
    if(std::abs(fullZoom-10)<.001f)checks|=1;
    if(std::abs((map.minX+map.maxX)/2+panX-player.x)<.001f&&std::abs((map.minZ+map.maxZ)/2+panY-player.z)<.001f&&displayedMap==player.map)checks|=2;
    Map fixture;fixture.idols={{1,"A",20,0,30},{2,"B",100,0,100}};
    if(HitIdol(fixture,ImVec2(250,200),ImVec2(0,0),ImVec2(500,400),20,30,4,16)==0&&HitIdol(fixture,ImVec2(-1,200),ImVec2(0,0),ImVec2(500,400),20,30,4,16)==-1&&HitIdol(fixture,ImVec2(50,50),ImVec2(0,0),ImVec2(500,400),20,30,4,16)==-1)checks|=4;
    bool policy=ResolveIdolState(false,true,true,false)==IdolState::Unknown&&ResolveIdolState(true,false,true,false)==IdolState::Unknown&&ResolveIdolState(true,true,false,false)==IdolState::Locked&&ResolveIdolState(true,true,false,true)==IdolState::Unavailable&&ResolveIdolState(true,true,true,true)==IdolState::Unavailable&&ResolveIdolState(true,true,true,false)==IdolState::Available;
    for(int state=0;state<4;state++)for(int alive=0;alive<2;alive++)for(int busy=0;busy<2;busy++)for(int allow=0;allow<2;allow++)policy&=CanTravel(static_cast<IdolState>(state),alive,busy,allow)==(alive&&!busy&&(state==3||(state==1&&allow)));
    if(policy)checks|=8;
    int availableMap=-1,availableIdol=-1;bool denied=true;
    for(size_t m=0;m<maps.size();m++)for(size_t i=0;i<maps[m].idols.size();i++){auto state=QueryIdol(maps[m].idols[i]);if(state==IdolState::Available){availableMap=static_cast<int>(m);availableIdol=static_cast<int>(i);}else denied&=!RequestTravel(static_cast<int>(m),static_cast<int>(i));}
    if(denied&&!RequestTravel(-1,0)&&!RequestTravel(0,9999))checks|=16;
    bool wasOpen=mapOpen;auto before=warpRequests;
    if(availableMap>=0&&RequestTravel(availableMap,availableIdol)&&!mapOpen&&travelBusy&&!RequestTravel(availableMap,availableIdol)){
        DispatchTravel();if(!travelBusy&&pendingTravelMap==-1&&lastTravelEntity==maps[availableMap].idols[availableIdol].entity&&warpRequests==before)checks|=32;
    }
    std::vector<unsigned char> warpBody(256,0xCC);unsigned char pattern[]={0x8D,0x8B,0xE8,0x03,0,0,0xE8,0,0,0,0,0x85,0xFF};memcpy(warpBody.data()+40,pattern,sizeof(pattern));int32_t displacement=400-(40+6+5);memcpy(warpBody.data()+47,&displacement,4);
    if(FindGlobal(warpBody,0x100000,{0x8D,0x8B,0xE8,0x03,0,0,0xE8,-1,-1,-1,-1,0x85,0xFF},6,1,5)==0x100000+400)checks|=64;
    int lockedMap=-1,lockedIdol=-1;for(size_t m=0;m<maps.size();m++)for(size_t i=0;i<maps[m].idols.size();i++)if(QueryIdol(maps[m].idols[i])==IdolState::Locked){lockedMap=static_cast<int>(m);lockedIdol=static_cast<int>(i);}
    if(lockedMap>=0){
        int last=lastTravelEntity;SetAllowLockedTravel(true);bool accepted=RequestTravel(lockedMap,lockedIdol);SetAllowLockedTravel(false);DispatchTravel();bool cancelled=!travelBusy&&lastTravelEntity==last;
        SetAllowLockedTravel(true);bool enabled=RequestTravel(lockedMap,lockedIdol);DispatchTravel();bool simulated=!travelBusy&&lastTravelEntity==maps[lockedMap].idols[lockedIdol].entity&&warpRequests==before;
        SetAllowLockedTravel(false);bool deniedLocked=!RequestTravel(lockedMap,lockedIdol);if(accepted&&cancelled&&enabled&&simulated&&deniedLocked&&!config.value("allowLockedTravel",true))checks|=128;
    }
    SetAllowLockedTravel(previousAllow);travelMessage.clear();SetMapOpen(wasOpen);return checks;
}
extern "C" __declspec(dllexport) unsigned AtlasControllerChecks(){
    if(!previewMode||!ready||!player.valid)return 0;unsigned checked=0;
    auto tap=[](WORD buttons){XINPUT_GAMEPAD state{};HandleController(state,0);state.wButtons=buttons;HandleController(state,0);state.wButtons=0;HandleController(state,0);};
    auto originalRadius=minimapRadius.load();bool wasOpen=mapOpen,previousAllow=allowLockedTravel;SetAllowLockedTravel(false);SetMapOpen(false);controllerButtons={};uiHidden=true;
    if(ControllerAxis(0)==0&&ControllerAxis(7849)==0&&ControllerAxis(-32768)==-1&&ControllerAxis(32767)==1&&ControllerTrigger(30)==0&&ControllerTrigger(255)==1)checked|=1;
    tap(XINPUT_GAMEPAD_BACK);tap(XINPUT_GAMEPAD_LEFT_SHOULDER);tap(XINPUT_GAMEPAD_DPAD_UP);bool singlesIgnored=!mapOpen;
    XINPUT_GAMEPAD held{};held.wButtons=ControllerMapChord;HandleController(held,0);bool once=mapOpen;HandleController(held,0);HandleController(held,0);if(singlesIgnored&&once&&mapOpen&&!uiHidden&&displayedMap==player.map&&std::abs(minimapRadius-originalRadius)<.01f)checked|=2;held.wButtons=0;HandleController(held,0);
    tap(XINPUT_GAMEPAD_B);if(!mapOpen)checked|=4;
    tap(ControllerMapChord);int current=displayedMap;tap(XINPUT_GAMEPAD_RIGHT_SHOULDER);bool changed=displayedMap!=(int)current;tap(XINPUT_GAMEPAD_LEFT_SHOULDER);if(changed&&displayedMap==current)checked|=8;
    fullZoom=2;float oldPan=panX;XINPUT_GAMEPAD analog{};analog.sThumbLX=32767;analog.bRightTrigger=255;HandleController(analog,.1f);float larger=fullZoom;analog.sThumbLX=0;analog.bRightTrigger=0;analog.bLeftTrigger=255;HandleController(analog,.1f);if(panX>oldPan&&larger>2&&fullZoom<larger)checked|=16;
    tap(XINPUT_GAMEPAD_DPAD_UP);bool increased=minimapRadius<originalRadius;tap(XINPUT_GAMEPAD_DPAD_DOWN);if(increased&&std::abs(minimapRadius-originalRadius)<.01f)checked|=32;
    int castle=-1;for(size_t i=0;i<maps.size();i++)if(maps[i].layers.size()>1)castle=static_cast<int>(i);if(castle>=0){displayedMap=castle;layerIndex=0;tap(XINPUT_GAMEPAD_RIGHT_THUMB);if(layerIndex==1)checked|=64;}
    tap(XINPUT_GAMEPAD_X);auto& map=maps[player.map];if(displayedMap==player.map&&std::abs(fullZoom-10)<.001f&&std::abs((map.minX+map.maxX)/2+panX-player.x)<.001f)checked|=128;
    RefreshIdols(true);tap(XINPUT_GAMEPAD_DPAD_RIGHT);int chosen=selectedIdol;auto requests=warpRequests;
    if(chosen>=0&&maps[displayedMap].idols[chosen].state==IdolState::Available){tap(XINPUT_GAMEPAD_A);bool issued=!mapOpen&&travelBusy;DispatchTravel();if(issued&&!travelBusy&&warpRequests==requests)checked|=256;}
    SetMapOpen(false);controllerButtons={};XINPUT_GAMEPAD chord{};chord.wButtons=XINPUT_GAMEPAD_LEFT_SHOULDER;HandleController(chord,0);bool firstOnly=!mapOpen;chord.wButtons=ControllerMapChord;HandleController(chord,0);bool opened=mapOpen;int region=displayedMap;chord.wButtons=XINPUT_GAMEPAD_DPAD_UP;HandleController(chord,0);chord.wButtons=ControllerMapChord;HandleController(chord,0);bool stillOpen=mapOpen;chord.wButtons=0;HandleController(chord,0);chord.wButtons=XINPUT_GAMEPAD_DPAD_UP;HandleController(chord,0);bool upOnly=mapOpen&&displayedMap==region;chord.wButtons=ControllerMapChord;HandleController(chord,0);bool closed=!mapOpen;chord.wButtons=0;HandleController(chord,0);
    bool latched=false;bool filtered=FilterMapChord(XINPUT_GAMEPAD_BACK,latched)==XINPUT_GAMEPAD_BACK&&FilterMapChord(XINPUT_GAMEPAD_LEFT_SHOULDER,latched)==XINPUT_GAMEPAD_LEFT_SHOULDER&&FilterMapChord(ControllerMapChord,latched)==0&&FilterMapChord(XINPUT_GAMEPAD_DPAD_UP,latched)==0&&FilterMapChord(0,latched)==0&&!latched;
    if(firstOnly&&opened&&stillOpen&&upOnly&&closed&&filtered&&std::abs(minimapRadius-originalRadius)<.01f)checked|=512;
    tap(ControllerMapChord);int lockedMap=-1,lockedIdol=-1;for(size_t m=0;m<maps.size();m++)for(size_t i=0;i<maps[m].idols.size();i++)if(QueryIdol(maps[m].idols[i])==IdolState::Locked){lockedMap=static_cast<int>(m);lockedIdol=static_cast<int>(i);}
    if(lockedMap>=0){tap(XINPUT_GAMEPAD_LEFT_THUMB);bool enabled=allowLockedTravel&&config.value("allowLockedTravel",false);displayedMap=lockedMap;selectedIdol=lockedIdol-1;ControllerSelectIdol(1);bool chosenLocked=selectedIdol==lockedIdol;tap(XINPUT_GAMEPAD_LEFT_THUMB);if(enabled&&chosenLocked&&!allowLockedTravel&&!config.value("allowLockedTravel",true))checked|=1024;}
    SetAllowLockedTravel(previousAllow);travelMessage.clear();controllerButtons={};SetMapOpen(wasOpen);if(wasOpen)CenterPlayerView();return checked;
}
BOOL WINAPI DllMain(HINSTANCE module,DWORD reason,LPVOID){if(reason==DLL_PROCESS_ATTACH){selfModule=module;DisableThreadLibraryCalls(module);auto thread=CreateThread(nullptr,0,Bootstrap,nullptr,0,nullptr);if(thread)CloseHandle(thread);}return TRUE;}
