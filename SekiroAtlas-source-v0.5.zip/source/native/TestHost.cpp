#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <d3d11.h>
#include <dxgi.h>
#include <filesystem>
#include <fstream>
#include <vector>
#include <string>
#include <cmath>
namespace fs=std::filesystem;
static void Capture(IDXGISwapChain* swap,ID3D11Device* device,ID3D11DeviceContext* context,const fs::path& path){
    ID3D11Texture2D* back=nullptr;if(FAILED(swap->GetBuffer(0,IID_ID3D11Texture2D,reinterpret_cast<void**>(&back))))return;
    D3D11_TEXTURE2D_DESC description{};back->GetDesc(&description);description.BindFlags=0;description.MiscFlags=0;description.Usage=D3D11_USAGE_STAGING;description.CPUAccessFlags=D3D11_CPU_ACCESS_READ;
    ID3D11Texture2D* staging=nullptr;if(FAILED(device->CreateTexture2D(&description,nullptr,&staging))){back->Release();return;}
    context->CopyResource(staging,back);D3D11_MAPPED_SUBRESOURCE mapped{};
    if(SUCCEEDED(context->Map(staging,0,D3D11_MAP_READ,0,&mapped))){
        BITMAPFILEHEADER file{};file.bfType=0x4D42;file.bfOffBits=sizeof(file)+sizeof(BITMAPINFOHEADER);file.bfSize=file.bfOffBits+description.Width*description.Height*4;
        BITMAPINFOHEADER info{};info.biSize=sizeof(info);info.biWidth=description.Width;info.biHeight=-static_cast<LONG>(description.Height);info.biPlanes=1;info.biBitCount=32;info.biCompression=BI_RGB;
        std::ofstream output(path,std::ios::binary);output.write(reinterpret_cast<char*>(&file),sizeof(file));output.write(reinterpret_cast<char*>(&info),sizeof(info));
        std::vector<unsigned char> row(description.Width*4);
        for(UINT y=0;y<description.Height;y++){auto input=static_cast<unsigned char*>(mapped.pData)+y*mapped.RowPitch;for(UINT x=0;x<description.Width;x++){row[x*4]=input[x*4+2];row[x*4+1]=input[x*4+1];row[x*4+2]=input[x*4];row[x*4+3]=255;}output.write(reinterpret_cast<char*>(row.data()),row.size());}
        context->Unmap(staging,0);
    }
    staging->Release();back->Release();
}
int main(){
    using DpiFn=BOOL(WINAPI*)(HANDLE);auto dpi=reinterpret_cast<DpiFn>(GetProcAddress(GetModuleHandleW(L"user32.dll"),"SetProcessDpiAwarenessContext"));if(dpi)dpi(DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2);
    wchar_t exe[32768]{};GetModuleFileNameW(nullptr,exe,32768);auto root=fs::path(exe).parent_path();
    HWND window=CreateWindowExW(0,L"STATIC",L"Atlas DX11 validation",WS_OVERLAPPED,0,0,1920,1080,nullptr,nullptr,GetModuleHandleW(nullptr),nullptr);
    DXGI_SWAP_CHAIN_DESC description{};description.BufferDesc.Width=1920;description.BufferDesc.Height=1080;description.BufferDesc.Format=DXGI_FORMAT_R8G8B8A8_UNORM;description.SampleDesc.Count=1;description.BufferUsage=DXGI_USAGE_RENDER_TARGET_OUTPUT;description.BufferCount=1;description.OutputWindow=window;description.Windowed=TRUE;description.SwapEffect=DXGI_SWAP_EFFECT_DISCARD;
    IDXGISwapChain* swap=nullptr;ID3D11Device* device=nullptr;ID3D11DeviceContext* context=nullptr;
    HRESULT result=D3D11CreateDeviceAndSwapChain(nullptr,D3D_DRIVER_TYPE_HARDWARE,nullptr,0,nullptr,0,D3D11_SDK_VERSION,&description,&swap,&device,nullptr,&context);
    if(FAILED(result))result=D3D11CreateDeviceAndSwapChain(nullptr,D3D_DRIVER_TYPE_WARP,nullptr,0,nullptr,0,D3D11_SDK_VERSION,&description,&swap,&device,nullptr,&context);
    if(FAILED(result)){return 2;}
    auto mod=LoadLibraryW((root/L"AtlasMod.dll").c_str());if(!mod)return 3;
    using PreviewFn=void(*)(int);auto preview=reinterpret_cast<PreviewFn>(GetProcAddress(mod,"AtlasPreview"));if(!preview)return 4;preview(0);Sleep(1500);
    auto render=[&](){ID3D11Texture2D* back=nullptr;ID3D11RenderTargetView* target=nullptr;swap->GetBuffer(0,IID_ID3D11Texture2D,reinterpret_cast<void**>(&back));device->CreateRenderTargetView(back,nullptr,&target);back->Release();const float clear[]={.035f,.05f,.06f,1};context->OMSetRenderTargets(1,&target,nullptr);context->ClearRenderTargetView(target,clear);target->Release();swap->Present(0,0);};
    for(int i=0;i<6;i++){render();Sleep(40);}Capture(swap,device,context,root/L"preview-minimap.bmp");
    preview(1);for(int i=0;i<6;i++){render();Sleep(40);}Capture(swap,device,context,root/L"preview-fullmap.bmp");
    using FeatureFn=unsigned(*)();auto features=reinterpret_cast<FeatureFn>(GetProcAddress(mod,"AtlasFeatureChecks"));if(!features)return 23;
    preview(-1);auto checked=features();if(checked!=255){std::ofstream(root/L"feature-failure.txt")<<checked;return 24;}
    auto controllerChecks=reinterpret_cast<FeatureFn>(GetProcAddress(mod,"AtlasControllerChecks"));if(!controllerChecks)return 26;
    auto controllerResult=controllerChecks();if(controllerResult!=2047){std::ofstream(root/L"controller-failure.txt")<<controllerResult;return 27;}
    render();
    preview(2);for(int i=0;i<4;i++)render();Capture(swap,device,context,root/L"preview-bosses.bmp");preview(1);for(int i=0;i<3;i++)render();preview(-1);
    context->OMSetRenderTargets(0,nullptr,nullptr);SetWindowPos(window,nullptr,0,0,1280,720,SWP_NOMOVE|SWP_NOZORDER|SWP_NOACTIVATE);swap->ResizeBuffers(0,1280,720,DXGI_FORMAT_UNKNOWN,0);
    for(int i=0;i<3;i++)render();Capture(swap,device,context,root/L"preview-resized.bmp");
    using StateFn=int(*)();auto state=reinterpret_cast<StateFn>(GetProcAddress(mod,"AtlasUIState"));if(!state)return 10;
    preview(-1);
    SendMessageW(window,WM_KEYDOWN,'M',0);if(state()&1)return 11;
    SendMessageW(window,WM_KEYDOWN,'M',0);if(!(state()&1))return 12;
    SendMessageW(window,WM_KEYDOWN,VK_ESCAPE,0);if(state()&1)return 13;
    SendMessageW(window,WM_KEYDOWN,VK_F9,0);if(!(state()&2))return 14;
    SendMessageW(window,WM_KEYDOWN,VK_F9,0);if(state()&2)return 15;
    using RadiusFn=float(*)();auto radius=reinterpret_cast<RadiusFn>(GetProcAddress(mod,"AtlasMinimapRadius"));if(!radius)return 16;
    float before=radius();SendMessageW(window,WM_KEYDOWN,VK_F7,0);if(radius()>=before)return 17;
    SendMessageW(window,WM_KEYDOWN,VK_F6,0);if(std::abs(radius()-before)>.01f)return 18;
    SendMessageW(window,WM_KEYDOWN,'M',0);
    if(GetAsyncKeyState(VK_LBUTTON)!=0 || GetAsyncKeyState(VK_RBUTTON)!=0)return 19;
    using CounterFn=unsigned long long(*)();auto cursorCount=reinterpret_cast<CounterFn>(GetProcAddress(mod,"AtlasBlockedCursorCalls"));if(!cursorCount)return 20;
    auto countBefore=cursorCount();POINT a{},b{};if(!GetCursorPos(&a)||cursorCount()<=countBefore)return 21;
    SetCursorPos(a.x,a.y);if(!GetCursorPos(&b)||a.x!=b.x||a.y!=b.y||cursorCount()<countBefore+3)return 22;
    SendMessageW(window,WM_KEYDOWN,VK_ESCAPE,0);
    std::ifstream status(root/L"atlas-runtime.json");std::string text((std::istreambuf_iterator<char>(status)),{});
    if(text.find("\"renderer\": true")==std::string::npos)return 5;
    SendMessageW(window,WM_KEYDOWN,'M',0);render();if(features()!=255)return 25;render();SendMessageW(window,WM_KEYDOWN,VK_ESCAPE,0);
    std::ofstream report(root/L"render-test.json");report<<"{\"passed\":true,\"checks\":[\"DX11 hook\",\"Chinese font\",\"minimap\",\"fullmap\",\"ResizeBuffers\",\"M toggle\",\"Esc close\",\"F9 hide and restore\",\"F6 F7 zoom\",\"mouse button polling blocked\",\"cursor movement isolated\",\"10x on every map opening\",\"player centered\",\"idol hit testing\",\"default locked travel denied; optional locked travel accepted; unavailable and unknown always rejected\",\"player readiness gate checked\",\"duplicate warp rejected\",\"preview warp cannot call game function\",\"warp request manager relative-call resolution\",\"Xbox LB + D-pad Up both press orders, hold debounce, no region or zoom conflict, View preserved\",\"Xbox analog pan and trigger zoom\",\"Xbox region idol and layer selection\",\"Xbox minimap zoom and simulated travel; L3 locked travel toggle saved\"],\"featureChecks\":255,\"controllerChecks\":2047,\"realGamePositionVerified\":false,\"realGameFastTravelVerified\":false}";
    return 0;
}
