#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <tlhelp32.h>
#include <filesystem>
#include <string>
#include <vector>
#include <cstring>
namespace fs=std::filesystem;
static bool quiet=false;
static fs::path appRoot;
static void WriteError(const wchar_t* text,DWORD error){
    auto path=appRoot/L"loader-error.txt";HANDLE file=CreateFileW(path.c_str(),GENERIC_WRITE,FILE_SHARE_READ,nullptr,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,nullptr);if(file==INVALID_HANDLE_VALUE)return;
    std::wstring message=std::wstring(text)+L"\r\nWindows error: "+std::to_wstring(error);wchar_t bom=0xFEFF;DWORD bytes=0;WriteFile(file,&bom,2,&bytes,nullptr);WriteFile(file,message.data(),static_cast<DWORD>(message.size()*2),&bytes,nullptr);CloseHandle(file);
}
static DWORD FindGame(){HANDLE snapshot=CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS,0);if(snapshot==INVALID_HANDLE_VALUE)return 0;PROCESSENTRY32W entry{};entry.dwSize=sizeof(entry);DWORD pid=0;if(Process32FirstW(snapshot,&entry))do{if(_wcsicmp(entry.szExeFile,L"sekiro.exe")==0){pid=entry.th32ProcessID;break;}}while(Process32NextW(snapshot,&entry));CloseHandle(snapshot);return pid;}
static uintptr_t FindModule(DWORD pid,const wchar_t* name){HANDLE snapshot=CreateToolhelp32Snapshot(TH32CS_SNAPMODULE|TH32CS_SNAPMODULE32,pid);if(snapshot==INVALID_HANDLE_VALUE)return 0;MODULEENTRY32W entry{};entry.dwSize=sizeof(entry);uintptr_t base=0;if(Module32FirstW(snapshot,&entry))do{if(_wcsicmp(entry.szModule,name)==0){base=reinterpret_cast<uintptr_t>(entry.modBaseAddr);break;}}while(Module32NextW(snapshot,&entry));CloseHandle(snapshot);return base;}
static int Error(const wchar_t* text){DWORD error=GetLastError();WriteError(text,error);if(!quiet)MessageBoxW(nullptr,text,L"只狼地图 · Sekiro Atlas",MB_OK|MB_ICONINFORMATION);return 1;}
int WINAPI WinMain(HINSTANCE,HINSTANCE,LPSTR command,int){
    quiet=command&&strstr(command,"--quiet");
    wchar_t exe[32768]{};GetModuleFileNameW(nullptr,exe,32768);auto dll=fs::path(exe).parent_path()/L"AtlasMod.dll";
    appRoot=fs::path(exe).parent_path();DeleteFileW((appRoot/L"loader-error.txt").c_str());
    if(!fs::exists(dll))return Error(L"同一目录中缺少 AtlasMod.dll。请完整解压整个文件夹。");
    DWORD pid=FindGame();if(!pid)return Error(L"请先启动《只狼》并进入主菜单或游戏，再运行 StartAtlas.exe。");
    if(FindModule(pid,L"AtlasMod.dll"))return Error(L"地图已加载。按 M 打开大地图，F9 隐藏小地图。");
    HANDLE process=OpenProcess(PROCESS_CREATE_THREAD|PROCESS_QUERY_INFORMATION|PROCESS_VM_OPERATION|PROCESS_VM_WRITE|PROCESS_VM_READ,FALSE,pid);
    if(!process)return Error(L"无法打开游戏进程。请让游戏和地图启动器使用相同的权限级别。");
    auto load=reinterpret_cast<void*>(GetProcAddress(GetModuleHandleW(L"kernel32.dll"),"LoadLibraryW"));HMODULE localOwner=nullptr;
    GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,reinterpret_cast<LPCWSTR>(load),&localOwner);
    wchar_t ownerPath[MAX_PATH]{};GetModuleFileNameW(localOwner,ownerPath,MAX_PATH);auto name=fs::path(ownerPath).filename().wstring();
    uintptr_t remoteBase=FindModule(pid,name.c_str());auto remoteLoad=remoteBase+reinterpret_cast<uintptr_t>(load)-reinterpret_cast<uintptr_t>(localOwner);
    if(!remoteBase){CloseHandle(process);return Error(L"无法解析游戏进程中的系统加载函数。");}
    auto path=dll.wstring();SIZE_T bytes=(path.size()+1)*sizeof(wchar_t);void* memory=VirtualAllocEx(process,nullptr,bytes,MEM_COMMIT|MEM_RESERVE,PAGE_READWRITE);SIZE_T written=0;
    if(!memory||!WriteProcessMemory(process,memory,path.c_str(),bytes,&written)||written!=bytes){if(memory)VirtualFreeEx(process,memory,0,MEM_RELEASE);CloseHandle(process);return Error(L"写入 Mod 加载路径失败。");}
    HANDLE thread=CreateRemoteThread(process,nullptr,0,reinterpret_cast<LPTHREAD_START_ROUTINE>(remoteLoad),memory,0,nullptr);
    if(!thread){VirtualFreeEx(process,memory,0,MEM_RELEASE);CloseHandle(process);return Error(L"加载线程创建失败。");}
    DWORD wait=WaitForSingleObject(thread,15000);CloseHandle(thread);
    if(wait==WAIT_OBJECT_0)VirtualFreeEx(process,memory,0,MEM_RELEASE);CloseHandle(process);
    if(wait!=WAIT_OBJECT_0)return Error(L"Mod 加载尚未完成。稍等片刻，检查 atlas.log。");
    if(!FindModule(pid,L"AtlasMod.dll"))return Error(L"Mod 未成功加载。请检查 atlas.log。");
    return 0;
}
