#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>
constexpr uint16_t ControllerMapChord=0x0101; // XInput LB + D-pad Up.
struct ControllerButtons {
    uint16_t previous=0,pending=0;
    bool latched=false;
    uint16_t Poll(uint16_t buttons,bool& toggle){
        uint16_t pressed=buttons&~previous,released=previous&~buttons;
        previous=buttons;toggle=false;
        uint16_t actions=pressed&~ControllerMapChord;
        if(latched){
            if(!(buttons&ControllerMapChord))latched=false;
            pending=0;
        }else{
            pending|=pressed&ControllerMapChord;
            if((buttons&ControllerMapChord)==ControllerMapChord){toggle=true;latched=true;pending=0;}
            else{actions|=released&pending;pending&=~released;}
        }
        return actions;
    }
};
inline uint16_t FilterMapChord(uint16_t buttons,bool& latched){
    if((buttons&ControllerMapChord)==ControllerMapChord)latched=true;
    else if(!(buttons&ControllerMapChord))latched=false;
    return latched?buttons&~ControllerMapChord:buttons;
}
inline float ControllerAxis(short value,int deadzone=7849){
    int magnitude=std::abs(static_cast<int>(value));
    if(magnitude<=deadzone)return 0;
    float normalized=std::clamp((magnitude-deadzone)/static_cast<float>(32767-deadzone),0.0f,1.0f);
    return value<0?-normalized:normalized;
}
inline float ControllerTrigger(unsigned char value){return value<=30?0.0f:(value-30)/225.0f;}
